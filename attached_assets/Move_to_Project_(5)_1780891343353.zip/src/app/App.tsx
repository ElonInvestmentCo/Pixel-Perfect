import { useState } from "react";
import { ReferralShare } from "./components/ReferralShare";

export default function App() {
  const [open, setOpen] = useState(true);

  return (
    <div className="size-full flex items-center justify-center bg-gray-100">
      {open ? (
        <ReferralShare onClose={() => setOpen(false)} />
      ) : (
        <button
          onClick={() => setOpen(true)}
          className="px-6 py-3 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors"
        >
          Open Share Sheet
        </button>
      )}
    </div>
  );
}
