import img20RefferalCodeShare from "../../imports/20RefferalCodeShare/a3cab625379319b2b263da2ae053cec49594c595.png";
import { Copy, Download, X } from "lucide-react";

const SOCIAL_APPS = [
  {
    name: "WeChat",
    bg: "bg-[#07C160]",
    icon: (
      <svg viewBox="0 0 24 24" fill="white" className="w-7 h-7">
        <path d="M9.5 4C5.36 4 2 6.91 2 10.5c0 2.02 1.06 3.82 2.72 5.01L4 17.5l2.09-1.05c.93.26 1.92.4 2.91.4.23 0 .46-.01.69-.03-.14-.45-.22-.92-.22-1.41C9.47 12.08 12.67 9.5 16.5 9.5c.2 0 .39.01.58.03C16.37 6.6 13.22 4 9.5 4zm-1.75 3.5a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm3.5 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm4.75 3C12.46 10.5 9.5 12.9 9.5 15.91c0 3.01 2.96 5.41 6.5 5.41.87 0 1.7-.14 2.46-.39L20.5 22l-.66-1.85C21.19 19.06 22 17.57 22 15.91c0-3.01-2.96-5.41-6.5-5.41zm-1.75 2.5a.75.75 0 1 1 0 1.5.75.75 0 0 1 0-1.5zm3.5 0a.75.75 0 1 1 0 1.5.75.75 0 0 1 0-1.5z" />
      </svg>
    ),
  },
  {
    name: "Instagram",
    bg: "bg-gradient-to-br from-[#F58529] via-[#DD2A7B] to-[#8134AF]",
    icon: (
      <svg viewBox="0 0 24 24" fill="white" className="w-7 h-7">
        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z" />
      </svg>
    ),
  },
  {
    name: "Twitter",
    bg: "bg-[#1DA1F2]",
    icon: (
      <svg viewBox="0 0 24 24" fill="white" className="w-7 h-7">
        <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" />
      </svg>
    ),
  },
  {
    name: "Slack",
    bg: "bg-white border border-gray-200",
    icon: (
      <svg viewBox="0 0 24 24" className="w-7 h-7">
        <path fill="#E01E5A" d="M5.042 15.165a2.528 2.528 0 01-2.52 2.523A2.528 2.528 0 010 15.165a2.527 2.527 0 012.522-2.52h2.52v2.52zm1.271 0a2.527 2.527 0 012.521-2.52 2.527 2.527 0 012.521 2.52v6.313A2.528 2.528 0 018.834 24a2.528 2.528 0 01-2.521-2.522v-6.313z" />
        <path fill="#36C5F0" d="M8.834 5.042a2.528 2.528 0 01-2.521-2.52A2.528 2.528 0 018.834 0a2.528 2.528 0 012.521 2.522v2.52H8.834zm0 1.271a2.528 2.528 0 012.521 2.521 2.528 2.528 0 01-2.521 2.521H2.522A2.528 2.528 0 010 8.834a2.528 2.528 0 012.522-2.521h6.312z" />
        <path fill="#2EB67D" d="M18.956 8.834a2.528 2.528 0 012.522-2.521A2.528 2.528 0 0124 8.834a2.528 2.528 0 01-2.522 2.521h-2.522V8.834zm-1.268 0a2.528 2.528 0 01-2.523 2.521 2.527 2.527 0 01-2.52-2.521V2.522A2.527 2.527 0 0115.165 0a2.528 2.528 0 012.523 2.522v6.312z" />
        <path fill="#ECB22E" d="M15.165 18.956a2.528 2.528 0 012.523 2.522A2.528 2.528 0 0115.165 24a2.527 2.527 0 01-2.52-2.522v-2.522h2.52zm0-1.268a2.527 2.527 0 01-2.52-2.523 2.526 2.526 0 012.52-2.52h6.313A2.527 2.527 0 0124 15.165a2.528 2.528 0 01-2.522 2.523h-6.313z" />
      </svg>
    ),
  },
];

interface ReferralShareProps {
  onClose?: () => void;
}

export function ReferralShare({ onClose }: ReferralShareProps) {
  return (
    <div className="relative w-[375px] h-[812px] overflow-hidden rounded-[40px] mx-auto shadow-2xl">
      {/* Background screen */}
      <img
        src={img20RefferalCodeShare}
        alt="Referral background"
        className="absolute inset-0 w-full h-full object-cover"
      />

      {/* Bottom sheet overlay */}
      <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-3xl pb-8">
        {/* Handle bar */}
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-gray-200" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3">
          <span className="text-[18px] font-semibold text-gray-900">Share</span>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        <div className="h-px bg-gray-100 mx-5" />

        {/* Social icons row */}
        <div className="flex justify-around px-5 py-6">
          {SOCIAL_APPS.map((app) => (
            <button
              key={app.name}
              className="flex flex-col items-center gap-2 group"
            >
              <div
                className={`w-[60px] h-[60px] rounded-full flex items-center justify-center ${app.bg} shadow-sm group-hover:scale-105 transition-transform`}
              >
                {app.icon}
              </div>
              <span className="text-[12px] text-gray-600">{app.name}</span>
            </button>
          ))}
        </div>

        {/* Copy Link */}
        <div className="mx-5 mb-3">
          <button className="w-full flex items-center justify-between px-4 py-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
            <span className="text-[15px] text-gray-800">Copy Link</span>
            <Copy size={20} className="text-gray-500" />
          </button>
        </div>

        {/* Save Image */}
        <div className="mx-5">
          <button className="w-full flex items-center justify-between px-4 py-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
            <span className="text-[15px] text-gray-800">Save Image</span>
            <Download size={20} className="text-gray-500" />
          </button>
        </div>
      </div>
    </div>
  );
}
