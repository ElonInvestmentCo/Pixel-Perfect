import img20RefferalCodeShare from "./a3cab625379319b2b263da2ae053cec49594c595.png";

export default function Component20RefferalCodeShare() {
  return (
    <div className="relative size-full" data-name="20. Refferal Code - Share">
      <div className="absolute h-[812px] left-0 top-0 w-[375px]" data-name="20. Refferal Code - Share">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={img20RefferalCodeShare} />
      </div>
    </div>
  );
}