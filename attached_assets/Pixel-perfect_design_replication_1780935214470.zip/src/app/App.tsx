import { Bell, Eye, ArrowUp, ArrowDown, Menu, Home, BarChart3, Scan, CreditCard, User } from 'lucide-react';
import profileImg from '../imports/IMG_1358-1.jpeg';

export default function App() {
  return (
    <div className="size-full bg-[#f8f8f8] flex items-center justify-center">
      {/* Mobile Frame */}
      <div className="w-[375px] h-[812px] bg-white overflow-hidden flex flex-col relative">
        {/* Status Bar */}
        <div className="px-6 pt-3 pb-2 flex items-center justify-between">
          <div className="font-semibold">9:41</div>
          <div className="flex items-center gap-1">
            <svg width="18" height="12" viewBox="0 0 18 12" fill="none">
              <rect x="0" y="2" width="3" height="8" rx="0.5" fill="black"/>
              <rect x="4.5" y="1" width="3" height="10" rx="0.5" fill="black"/>
              <rect x="9" y="0" width="3" height="12" rx="0.5" fill="black"/>
              <rect x="13.5" y="1.5" width="3" height="9" rx="0.5" fill="black"/>
            </svg>
            <svg width="17" height="12" viewBox="0 0 17 12" fill="none">
              <path d="M8.5 0C5.85 0 3.45 1.23 2 3.18C3.45 5.13 5.85 6.36 8.5 6.36C11.15 6.36 13.55 5.13 15 3.18C13.55 1.23 11.15 0 8.5 0ZM8.5 5.09C6.85 5.09 5.5 3.87 5.5 2.36C5.5 0.85 6.85 -0.36 8.5 -0.36C10.15 -0.36 11.5 0.85 11.5 2.36C11.5 3.87 10.15 5.09 8.5 5.09Z" fill="black"/>
              <path d="M0 11.5C0.5 11.5 1 11.5 1.5 11.4C2 11.3 2.5 11.1 3 10.9C3.5 10.7 4 10.4 4.4 10.1C4.8 9.8 5.2 9.4 5.5 9C5.8 8.6 6 8.1 6.2 7.6C6.4 7.1 6.5 6.6 6.5 6C6.5 5.4 6.4 4.9 6.2 4.4C6 3.9 5.8 3.4 5.5 3C5.2 2.6 4.8 2.2 4.4 1.9C4 1.6 3.5 1.3 3 1.1C2.5 0.9 2 0.7 1.5 0.6C1 0.5 0.5 0.5 0 0.5V11.5Z" fill="black"/>
            </svg>
            <div className="relative">
              <div className="w-[24px] h-[11px] border-2 border-black rounded-[3px] opacity-35"/>
              <div className="absolute top-[2px] right-[-1.5px] w-[1.5px] h-[7px] bg-black opacity-40 rounded-r-sm"/>
              <div className="absolute top-[2px] left-[2px] w-[18px] h-[7px] bg-black rounded-[1.5px]"/>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 px-5 overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-[60px] h-[60px] rounded-full bg-gray-200 overflow-hidden">
                <div className="w-full h-full bg-gradient-to-br from-gray-300 to-gray-400"/>
              </div>
              <div>
                <div className="text-[22px] font-semibold leading-tight">Hi, Jennifer</div>
                <div className="text-[15px] text-gray-600">Good Morning!</div>
              </div>
            </div>
            <button className="relative">
              <Bell className="w-6 h-6" strokeWidth={1.5}/>
              <div className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-red-500 rounded-full"/>
            </button>
          </div>

          {/* Balance Section */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[15px] text-gray-700">Total Balance</span>
              <Eye className="w-5 h-5 text-gray-500" strokeWidth={1.5}/>
            </div>
            <div className="text-[52px] font-bold leading-none tracking-tight">$12,765.00</div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-3 mb-6">
            <button className="flex-1 h-[68px] bg-[#d4ff00] rounded-full flex items-center justify-center gap-3 hover:bg-[#c4ef00] transition-colors">
              <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                <ArrowUp className="w-5 h-5" strokeWidth={2.5}/>
              </div>
              <span className="text-[17px] font-semibold">Transfer</span>
            </button>
            <button className="flex-1 h-[68px] bg-[#d4ff00] rounded-full flex items-center justify-center gap-3 hover:bg-[#c4ef00] transition-colors">
              <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                <ArrowDown className="w-5 h-5" strokeWidth={2.5}/>
              </div>
              <span className="text-[17px] font-semibold">Receive</span>
            </button>
            <button className="w-[68px] h-[68px] bg-[#d4ff00] rounded-full flex items-center justify-center hover:bg-[#c4ef00] transition-colors">
              <Menu className="w-6 h-6" strokeWidth={2.5}/>
            </button>
          </div>

          {/* Promo Card */}
          <div className="relative h-[200px] bg-gradient-to-br from-[#6366f1] via-[#7c3aed] to-[#8b5cf6] rounded-[28px] p-6 mb-6 overflow-hidden">
            <div className="absolute top-8 right-8 w-28 h-28 bg-white/10 rounded-full blur-2xl"/>
            <div className="absolute bottom-8 right-16 w-20 h-20 bg-white/5 rounded-full"/>
            <div className="relative z-10">
              <div className="text-white text-[26px] font-bold leading-tight mb-4">
                Invite a friend and<br/>both earn cashback
              </div>
              <div className="flex items-center gap-2 text-[#d4ff00] text-[16px] font-semibold">
                <span>Invite friends</span>
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                  <path d="M4 10H16M16 10L11 5M16 10L11 15" stroke="#d4ff00" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
            </div>
          </div>

          {/* Transactions Header */}
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-[24px] font-bold">Transactions</h2>
            <button className="text-[#6366f1] text-[15px] font-medium">See All</button>
          </div>

          {/* Transactions List */}
          <div className="space-y-3 pb-24">
            {/* Transaction 1 - Figma */}
            <div className="bg-white border border-gray-200 rounded-[20px] p-4 flex items-center gap-4">
              <div className="w-14 h-14 bg-[#ede9fe] rounded-2xl flex items-center justify-center flex-shrink-0">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                  <path d="M8 24C10.2091 24 12 22.2091 12 20V16H8C5.79086 16 4 17.7909 4 20C4 22.2091 5.79086 24 8 24Z" fill="#0ACF83"/>
                  <path d="M4 12C4 9.79086 5.79086 8 8 8H12V16H8C5.79086 16 4 14.2091 4 12Z" fill="#A259FF"/>
                  <path d="M4 4C4 1.79086 5.79086 0 8 0H12V8H8C5.79086 8 4 6.20914 4 4Z" fill="#F24E1E"/>
                  <path d="M12 0H16C18.2091 0 20 1.79086 20 4C20 6.20914 18.2091 8 16 8H12V0Z" fill="#FF7262"/>
                  <path d="M20 12C20 14.2091 18.2091 16 16 16C13.7909 16 12 14.2091 12 12C12 9.79086 13.7909 8 16 8C18.2091 8 20 9.79086 20 12Z" fill="#1ABCFE"/>
                </svg>
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[17px] font-semibold mb-0.5">Figma</div>
                <div className="text-[14px] text-gray-500">Today, 12:30 PM</div>
              </div>
              <div className="text-right">
                <div className="text-[17px] font-semibold">-$250.00</div>
                <div className="text-[14px] text-gray-500">Subscriptions</div>
              </div>
            </div>

            {/* Transaction 2 - Receive from Alex */}
            <div className="bg-white border border-gray-200 rounded-[20px] p-4 flex items-center gap-4">
              <div className="w-14 h-14 bg-[#d4ff00] rounded-2xl flex items-center justify-center flex-shrink-0">
                <ArrowDown className="w-6 h-6" strokeWidth={2.5}/>
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[17px] font-semibold mb-0.5">Receive from Alex</div>
                <div className="text-[14px] text-gray-500">Yesterday, 08:00 AM</div>
              </div>
              <div className="text-right">
                <div className="text-[17px] font-semibold">+$580.00</div>
                <div className="text-[14px] text-gray-500">Money In</div>
              </div>
            </div>

            {/* Transaction 3 - Medium */}
            <div className="bg-white border border-gray-200 rounded-[20px] p-4 flex items-center gap-4">
              <div className="w-14 h-14 bg-[#fef3c7] rounded-2xl flex items-center justify-center flex-shrink-0">
                <svg width="32" height="18" viewBox="0 0 32 18" fill="black">
                  <path d="M3.6 0C1.61177 0 0 1.61177 0 3.6V14.4C0 16.3882 1.61177 18 3.6 18C5.58823 18 7.2 16.3882 7.2 14.4V3.6C7.2 1.61177 5.58823 0 3.6 0Z"/>
                  <path d="M13.6 0C11.6118 0 10 1.61177 10 3.6V14.4C10 16.3882 11.6118 18 13.6 18C15.5882 18 17.2 16.3882 17.2 14.4V3.6C17.2 1.61177 15.5882 0 13.6 0Z"/>
                  <ellipse cx="25.6" cy="9" rx="3.6" ry="9" fill="black"/>
                </svg>
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[17px] font-semibold mb-0.5">Medium</div>
                <div className="text-[14px] text-gray-500">May 10, 06:00 PM</div>
              </div>
              <div className="text-right">
                <div className="text-[17px] font-semibold">-$99.00</div>
                <div className="text-[14px] text-gray-500">Subscriptions</div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Navigation */}
        <div className="absolute bottom-0 left-0 right-0 bg-white border-t border-gray-200 pb-6">
          <div className="flex items-center justify-around px-4 pt-3">
            <button className="flex flex-col items-center gap-1">
              <Home className="w-6 h-6" strokeWidth={2} fill="black"/>
              <span className="text-[11px] font-medium">Home</span>
            </button>
            <button className="flex flex-col items-center gap-1">
              <BarChart3 className="w-6 h-6 text-gray-400" strokeWidth={2}/>
              <span className="text-[11px] text-gray-400">Insights</span>
            </button>
            <button className="w-14 h-14 bg-[#d4ff00] rounded-full flex items-center justify-center -mt-6">
              <Scan className="w-7 h-7" strokeWidth={2}/>
            </button>
            <button className="flex flex-col items-center gap-1">
              <CreditCard className="w-6 h-6 text-gray-400" strokeWidth={2}/>
              <span className="text-[11px] text-gray-400">My Cards</span>
            </button>
            <button className="flex flex-col items-center gap-1">
              <User className="w-6 h-6 text-gray-400" strokeWidth={2}/>
              <span className="text-[11px] text-gray-400">Profile</span>
            </button>
          </div>
          {/* iPhone Home Indicator */}
          <div className="flex justify-center mt-2">
            <div className="w-[134px] h-[5px] bg-black rounded-full"/>
          </div>
        </div>
      </div>
    </div>
  );
}