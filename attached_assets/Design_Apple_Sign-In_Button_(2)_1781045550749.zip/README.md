
  # Design Google Sign-In Button

  This is a code bundle for Design Google Sign-In Button. The original project is available at https://www.figma.com/design/9rakjhwmzS3w2vCNlHrESu/Design-Google-Sign-In-Button.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  