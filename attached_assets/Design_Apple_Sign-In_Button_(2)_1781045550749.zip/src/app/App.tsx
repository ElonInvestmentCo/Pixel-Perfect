import { AppleSignInButton } from "./components/AppleSignInButton";

export default function App() {
  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "#f2f2f7",
      }}
    >
      <AppleSignInButton />
    </div>
  );
}
