import { useState } from "react";

const AppleLogo = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    width="14"
    height="14"
    fill="#000000"
    aria-hidden="true"
  >
    <path d="M12.152 6.896c-.948 0-2.415-1.078-3.96-1.04-2.04.027-3.91 1.183-4.961 3.014-2.117 3.675-.54 9.103 1.519 12.09 1.013 1.454 2.208 3.09 3.792 3.029 1.52-.065 2.09-.987 3.935-.987 1.831 0 2.35.987 3.96.948 1.637-.026 2.676-1.48 3.676-2.948 1.156-1.688 1.636-3.325 1.662-3.415-.039-.013-3.182-1.221-3.22-4.857-.026-3.04 2.48-4.494 2.597-4.559-1.429-2.09-3.623-2.324-4.402-2.376-2-.156-3.675 1.09-4.6 1.09zm3.378-3.066c.843-1.012 1.4-2.427 1.245-3.83-1.207.052-2.662.805-3.532 1.818-.78.896-1.454 2.338-1.273 3.714 1.338.104 2.715-.688 3.56-1.702z" />
  </svg>
);

export function AppleSignInButton({ onClick }: { onClick?: () => void }) {
  const [isHovered, setIsHovered] = useState(false);
  const [isPressed, setIsPressed] = useState(false);

  return (
    <button
      type="button"
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => { setIsHovered(false); setIsPressed(false); }}
      onMouseDown={() => setIsPressed(true)}
      onMouseUp={() => setIsPressed(false)}
      aria-label="Sign in with Apple"
      style={{
        position: "relative",
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: "6px",
        paddingLeft: "14px",
        paddingRight: "16px",
        paddingTop: "0",
        paddingBottom: "0",
        height: "32px",
        background: "#ffffff",
        border: "1px solid #000000",
        borderRadius: "16px",
        cursor: "pointer",
        outline: "none",
        WebkitTapHighlightColor: "transparent",
        userSelect: "none",
        transition: "box-shadow 0.15s ease, transform 0.08s ease",
        boxShadow: isPressed
          ? "none"
          : isHovered
          ? "0 2px 8px rgba(0,0,0,0.18)"
          : "none",
        transform: isPressed ? "scale(0.985)" : "scale(1)",
        whiteSpace: "nowrap",
        WebkitFontSmoothing: "antialiased",
        MozOsxFontSmoothing: "grayscale",
      }}
    >
      {/* Interaction overlay */}
      <div
        aria-hidden
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: "16px",
          background: isPressed
            ? "rgba(0,0,0,0.10)"
            : isHovered
            ? "rgba(0,0,0,0.05)"
            : "transparent",
          transition: "background 0.12s ease",
          pointerEvents: "none",
        }}
      />

      {/* Apple logo */}
      <span
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
          lineHeight: 0,
          marginTop: "-1px",
        }}
      >
        <AppleLogo />
      </span>

      {/* Label */}
      <span
        style={{
          position: "relative",
          fontFamily:
            "-apple-system, 'SF Pro Text', BlinkMacSystemFont, 'Helvetica Neue', Helvetica, Arial, sans-serif",
          fontWeight: 600,
          fontSize: "13px",
          lineHeight: "16px",
          letterSpacing: "-0.32px",
          color: "#000000",
        }}
      >
        Sign in with Apple
      </span>
    </button>
  );
}
