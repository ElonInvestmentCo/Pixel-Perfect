import svgPaths from "./svg-e68p951m5c";
import { imgGroup } from "./svg-9xnt5";

function Group() {
  return (
    <div className="absolute inset-0 mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-size-[20px_20px]" style={{ maskImage: `url("${imgGroup}")` }} data-name="Group">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.6 20">
        <g id="Group">
          <path d={svgPaths.p1de9a1f0} fill="var(--fill-0, #4285F4)" id="Vector" />
          <path d={svgPaths.pfdb82b0} fill="var(--fill-0, #34A853)" id="Vector_2" />
          <path d={svgPaths.p15ba0400} fill="var(--fill-0, #FBBC04)" id="Vector_3" />
          <path d={svgPaths.p28688f80} fill="var(--fill-0, #E94235)" id="Vector_4" />
        </g>
      </svg>
    </div>
  );
}

export default function ClipPathGroup() {
  return (
    <div className="contents relative size-full" data-name="Clip path group">
      <Group />
    </div>
  );
}