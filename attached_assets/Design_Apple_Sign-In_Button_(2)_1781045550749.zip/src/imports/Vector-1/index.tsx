import svgPaths from "./svg-uznd52vfj1";

export default function Vector() {
  return (
    <div className="relative size-full" data-name="Vector">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 119.499 13.4189">
        <path d={svgPaths.p2b47d100} fill="var(--fill-0, #1F1F1F)" id="Vector" />
      </svg>
    </div>
  );
}