import svgPaths from "./svg-ecl2gsxaws";

export default function Vector() {
  return (
    <div className="relative size-full" data-name="Vector">
      <div className="absolute inset-[-1.28%_-0.27%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 189 40">
          <path d={svgPaths.p31337b80} id="Vector" stroke="var(--stroke-0, #747775)" />
        </svg>
      </div>
    </div>
  );
}