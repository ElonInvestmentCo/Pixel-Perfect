import svgPaths from "./svg-j8tslmcwdn";

export default function Vector() {
  return (
    <div className="relative size-full" data-name="Vector">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 174 39">
        <path d={svgPaths.p7dfb880} fill="var(--fill-0, white)" id="Vector" />
      </svg>
    </div>
  );
}