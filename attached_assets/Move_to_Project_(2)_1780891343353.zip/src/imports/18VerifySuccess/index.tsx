import img18VerifySuccess from "./d74899dad1aa9bbd3f2f6461063cd95888cbd4d3.png";

export default function Component18VerifySuccess() {
  return (
    <div className="relative size-full" data-name="18. Verify Success">
      <div className="absolute h-[812px] left-0 top-0 w-[375px]" data-name="18. Verify Success">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={img18VerifySuccess} />
      </div>
    </div>
  );
}