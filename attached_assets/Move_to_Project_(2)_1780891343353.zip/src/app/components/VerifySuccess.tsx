import { Check } from "lucide-react";

interface VerifySuccessProps {
  onDone?: () => void;
}

export function VerifySuccess({ onDone }: VerifySuccessProps) {
  return (
    <div className="relative flex flex-col items-center justify-between bg-[#5B5BD6] w-full max-w-[375px] h-[812px] mx-auto overflow-hidden">
      {/* Status bar */}
      <div className="w-full px-6 pt-3 flex justify-between items-center text-white text-sm font-medium">
        <span>9:41</span>
        <div className="flex items-center gap-1">
          <svg width="17" height="12" viewBox="0 0 17 12" fill="none">
            <rect x="0" y="3" width="3" height="9" rx="1" fill="white" fillOpacity="0.4"/>
            <rect x="4.5" y="2" width="3" height="10" rx="1" fill="white" fillOpacity="0.6"/>
            <rect x="9" y="0" width="3" height="12" rx="1" fill="white"/>
            <rect x="13.5" y="0" width="3" height="12" rx="1" fill="white"/>
          </svg>
          <svg width="16" height="12" viewBox="0 0 16 12" fill="white">
            <path d="M8 2.4C10.56 2.4 12.86 3.46 14.5 5.18L16 3.62C13.96 1.38 11.14 0 8 0C4.86 0 2.04 1.38 0 3.62L1.5 5.18C3.14 3.46 5.44 2.4 8 2.4Z"/>
            <path d="M8 5.6C9.78 5.6 11.4 6.3 12.6 7.46L14.1 5.9C12.5 4.36 10.36 3.4 8 3.4C5.64 3.4 3.5 4.36 1.9 5.9L3.4 7.46C4.6 6.3 6.22 5.6 8 5.6Z"/>
            <circle cx="8" cy="10" r="2" fill="white"/>
          </svg>
          <svg width="25" height="12" viewBox="0 0 25 12" fill="none">
            <rect x="0.5" y="0.5" width="21" height="11" rx="3.5" stroke="white" strokeOpacity="0.35"/>
            <rect x="2" y="2" width="16" height="8" rx="2" fill="white"/>
            <path d="M23 4.5V7.5C23.8 7.17 24.5 6.43 24.5 6C24.5 5.57 23.8 4.83 23 4.5Z" fill="white" fillOpacity="0.4"/>
          </svg>
        </div>
      </div>

      {/* Center content */}
      <div className="flex flex-col items-center gap-6 flex-1 justify-center">
        {/* Ripple rings + check icon */}
        <div className="relative flex items-center justify-center w-[220px] h-[220px]">
          {/* Outer ring */}
          <div className="absolute w-[220px] h-[220px] rounded-full bg-white/10" />
          {/* Middle ring */}
          <div className="absolute w-[160px] h-[160px] rounded-full bg-white/15" />
          {/* Inner ring */}
          <div className="absolute w-[100px] h-[100px] rounded-full bg-white/20" />
          {/* Check circle */}
          <div className="relative z-10 w-[72px] h-[72px] rounded-full bg-[#C8F000] flex items-center justify-center shadow-lg">
            <Check className="w-8 h-8 text-[#1a1a1a]" strokeWidth={3} />
          </div>
        </div>

        {/* Text */}
        <div className="flex flex-col items-center gap-2 text-center px-8">
          <h1 className="text-white text-2xl font-bold">You're approved!</h1>
          <p className="text-white/70 text-sm">You're already to start using QPay</p>
        </div>
      </div>

      {/* Done button */}
      <div className="w-full px-5 pb-10">
        <button
          onClick={onDone}
          className="w-full h-[56px] rounded-2xl bg-[#C8F000] text-[#1a1a1a] font-semibold text-base hover:bg-[#d4f520] active:bg-[#b8df00] transition-colors"
        >
          Done
        </button>
        {/* Home indicator */}
        <div className="flex justify-center mt-4">
          <div className="w-32 h-1 bg-white/30 rounded-full" />
        </div>
      </div>
    </div>
  );
}
