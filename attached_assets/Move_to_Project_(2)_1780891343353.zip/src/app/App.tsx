import { VerifySuccess } from "./components/VerifySuccess";

export default function App() {
  return (
    <div className="size-full flex items-center justify-center bg-gray-100">
      <VerifySuccess onDone={() => alert("Done!")} />
    </div>
  );
}
