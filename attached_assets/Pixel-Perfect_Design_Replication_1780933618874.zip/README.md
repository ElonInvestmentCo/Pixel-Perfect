
  # Pixel-Perfect Design Replication

  This is a code bundle for Pixel-Perfect Design Replication. The original project is available at https://www.figma.com/design/2cSc83zKA2RLOxUrctthDr/Pixel-Perfect-Design-Replication.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  