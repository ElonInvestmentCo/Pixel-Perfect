import { motion } from "motion/react";

export function InviteBanner() {
  return (
    <motion.div
      whileTap={{ scale: 0.975 }}
      whileHover={{ scale: 1.008 }}
      transition={{ type: "spring", stiffness: 350, damping: 30 }}
      style={{
        margin: "0 22px",
        borderRadius: 22,
        background: "linear-gradient(130deg, #5540FF 0%, #6B52FF 45%, #7B62FF 100%)",
        padding: "22px 26px",
        position: "relative",
        overflow: "hidden",
        cursor: "pointer",
        minHeight: 110,
      }}
    >
      {/* Large blurred circle — far right top */}
      <div
        style={{
          position: "absolute",
          right: -24,
          top: -28,
          width: 130,
          height: 130,
          borderRadius: "50%",
          background: "rgba(255,255,255,0.10)",
        }}
      />

      {/* Medium ring — right center */}
      <div
        style={{
          position: "absolute",
          right: 14,
          top: "50%",
          transform: "translateY(-50%)",
          width: 80,
          height: 80,
          borderRadius: "50%",
          border: "2px solid rgba(255,255,255,0.18)",
        }}
      />

      {/* Small inner ring — inside the medium ring */}
      <div
        style={{
          position: "absolute",
          right: 34,
          top: "50%",
          transform: "translateY(-50%)",
          width: 40,
          height: 40,
          borderRadius: "50%",
          border: "1.5px solid rgba(255,255,255,0.12)",
        }}
      />

      {/* Bottom-right faint blob */}
      <div
        style={{
          position: "absolute",
          right: -10,
          bottom: -30,
          width: 90,
          height: 90,
          borderRadius: "50%",
          background: "rgba(255,255,255,0.06)",
        }}
      />

      {/* Content */}
      <div style={{ position: "relative", maxWidth: "60%" }}>
        <p
          style={{
            color: "#FFFFFF",
            fontSize: 20,
            fontWeight: 800,
            lineHeight: 1.3,
            margin: 0,
            letterSpacing: -0.4,
          }}
        >
          Invite a friend and{"\n"}both earn cashback
        </p>
        <p
          style={{
            color: "#C9FF00",
            fontSize: 14,
            fontWeight: 700,
            margin: "12px 0 0",
            letterSpacing: -0.1,
          }}
        >
          Invite friends →
        </p>
      </div>
    </motion.div>
  );
}
