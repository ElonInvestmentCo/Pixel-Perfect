export function StatusBar() {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "14px 26px 0",
        height: 48,
        flexShrink: 0,
      }}
    >
      {/* Time */}
      <span
        style={{
          fontSize: 15,
          fontWeight: 700,
          color: "#1A1A1A",
          letterSpacing: -0.5,
        }}
      >
        9:41
      </span>

      {/* Right status icons */}
      <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
        {/* Signal bars */}
        <svg width="18" height="12" viewBox="0 0 18 12" fill="none">
          <rect x="0" y="8" width="3" height="4" rx="0.8" fill="#1A1A1A" />
          <rect x="5" y="5.5" width="3" height="6.5" rx="0.8" fill="#1A1A1A" />
          <rect x="10" y="3" width="3" height="9" rx="0.8" fill="#1A1A1A" />
          <rect x="15" y="0" width="3" height="12" rx="0.8" fill="#1A1A1A" />
        </svg>

        {/* Wi-Fi */}
        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
          <path
            d="M8 9.5a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5Z"
            fill="#1A1A1A"
          />
          <path
            d="M3.8 6.9A5.9 5.9 0 0 1 8 5.2c1.62 0 3.09.65 4.16 1.7"
            stroke="#1A1A1A"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
          <path
            d="M1 4.1A9.8 9.8 0 0 1 8 1c2.72 0 5.18 1.1 6.96 2.88"
            stroke="#1A1A1A"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
        </svg>

        {/* Battery */}
        <svg width="26" height="13" viewBox="0 0 26 13" fill="none">
          <rect
            x="0.75"
            y="0.75"
            width="22.5"
            height="11.5"
            rx="3.25"
            stroke="#1A1A1A"
            strokeOpacity="0.35"
            strokeWidth="1.5"
          />
          <rect x="2" y="2" width="18" height="9" rx="2" fill="#1A1A1A" />
          <path
            d="M24 5v3c.9-.35 1.5-1 1.5-1.5S24.9 5.35 24 5Z"
            fill="#1A1A1A"
            fillOpacity="0.4"
          />
        </svg>
      </div>
    </div>
  );
}
