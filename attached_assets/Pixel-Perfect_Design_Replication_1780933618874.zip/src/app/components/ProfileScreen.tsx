import { motion } from "motion/react";
import { InviteBanner } from "./InviteBanner";

const AVATAR = "https://images.unsplash.com/photo-1644718847160-52a922094f69?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMHdvbWFuJTIwcG9ydHJhaXQlMjBhdmF0YXIlMjBwcm9maWxlfGVufDF8fHx8MTc4MDkzMDk0M3ww&ixlib=rb-4.1.0&q=80&w=400";

interface MenuItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  danger?: boolean;
}

function MemberIDIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <rect x="2" y="3" width="20" height="18" rx="3" stroke="#5B3EFF" strokeWidth="1.8"/>
      <circle cx="9" cy="10" r="2.5" stroke="#5B3EFF" strokeWidth="1.6"/>
      <path d="M5 17C5 14.8 6.8 13 9 13C11.2 13 13 14.8 13 17" stroke="#5B3EFF" strokeWidth="1.6" strokeLinecap="round"/>
      <path d="M15 9H19M15 13H17" stroke="#5B3EFF" strokeWidth="1.6" strokeLinecap="round"/>
    </svg>
  );
}

function SettingsIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <path d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" stroke="#5B3EFF" strokeWidth="1.8"/>
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" stroke="#5B3EFF" strokeWidth="1.5" fill="none"/>
    </svg>
  );
}

function LockIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <rect x="3" y="11" width="18" height="12" rx="3" stroke="#5B3EFF" strokeWidth="1.8"/>
      <path d="M7 11V7C7 4.239 9.239 2 12 2C14.761 2 17 4.239 17 7V11" stroke="#5B3EFF" strokeWidth="1.8" strokeLinecap="round"/>
      <circle cx="12" cy="16" r="1.5" fill="#5B3EFF"/>
    </svg>
  );
}

function HelpIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="10" stroke="#5B3EFF" strokeWidth="1.8"/>
      <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" stroke="#5B3EFF" strokeWidth="1.8" strokeLinecap="round"/>
      <circle cx="12" cy="17" r="1" fill="#5B3EFF"/>
    </svg>
  );
}

function LogoutIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" stroke="#FF3B30" strokeWidth="1.8" strokeLinecap="round"/>
      <path d="M16 17l5-5-5-5" stroke="#FF3B30" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M21 12H9" stroke="#FF3B30" strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  );
}

function ChevronRight({ danger }: { danger?: boolean }) {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
      <path d="M9 18L15 12L9 6" stroke={danger ? "#FF3B30" : "#ABABAB"} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

const menuItems: MenuItem[] = [
  { id: "member", label: "Member ID", icon: <MemberIDIcon /> },
  { id: "settings", label: "Settings", icon: <SettingsIcon /> },
  { id: "privacy", label: "Privacy & Security", icon: <LockIcon /> },
  { id: "help", label: "Help Center", icon: <HelpIcon /> },
  { id: "logout", label: "Log Out", icon: <LogoutIcon />, danger: true },
];

interface ProfileScreenProps {
  onBack?: () => void;
}

export function ProfileScreen({ onBack }: ProfileScreenProps) {
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#FFFFFF", overflowY: "auto" }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: "16px 20px 8px", position: "relative" }}>
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onBack}
          style={{
            position: "absolute", left: 20,
            width: 36, height: 36, borderRadius: "50%",
            background: "#F5F5F5", border: "none",
            display: "flex", alignItems: "center", justifyContent: "center",
            cursor: "pointer",
          }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
            <path d="M15 18L9 12L15 6" stroke="#1A1A1A" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </motion.button>
        <span style={{ fontSize: 17, fontWeight: 700, color: "#1A1A1A" }}>Profile</span>
      </div>

      {/* Avatar + Name */}
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "16px 20px 24px" }}>
        <div style={{
          width: 88, height: 88, borderRadius: "50%",
          background: "#E5E7EB", overflow: "hidden",
          border: "3px solid #F3F4F6",
          boxShadow: "0 4px 16px rgba(0,0,0,0.1)",
        }}>
          <img src={AVATAR} alt="Jennifer Lopez" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        </div>
        <p style={{ margin: "14px 0 0", fontSize: 20, fontWeight: 700, color: "#1A1A1A" }}>Jennifer Lopez</p>
        <p style={{ margin: "4px 0 0", fontSize: 13, color: "#9CA3AF" }}>Personal Account</p>
      </div>

      {/* Invite Banner */}
      <div style={{ marginBottom: 28 }}>
        <InviteBanner />
      </div>

      {/* Menu Items */}
      <div style={{ padding: "0 20px", display: "flex", flexDirection: "column" }}>
        {menuItems.map((item, i) => (
          <div key={item.id}>
            <motion.button
              whileTap={{ backgroundColor: "#F9F9F9" }}
              style={{
                display: "flex", alignItems: "center", gap: 16,
                width: "100%", background: "none", border: "none",
                padding: "16px 0", cursor: "pointer", textAlign: "left",
              }}>
              <div style={{
                width: 42, height: 42, borderRadius: 12,
                background: item.danger ? "#FFF0EE" : "#F0EDFF",
                display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
              }}>
                {item.icon}
              </div>
              <span style={{ flex: 1, fontSize: 16, fontWeight: 500, color: item.danger ? "#FF3B30" : "#1A1A1A" }}>
                {item.label}
              </span>
              <ChevronRight danger={item.danger} />
            </motion.button>
            {i < menuItems.length - 1 && (
              <div style={{ height: 1, background: "rgba(0,0,0,0.06)", marginLeft: 58 }} />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
