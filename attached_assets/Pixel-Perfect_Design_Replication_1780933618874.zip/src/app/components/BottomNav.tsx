import { motion } from "motion/react";

type Tab = "home" | "insights" | "scan" | "cards" | "profile";

interface BottomNavProps {
  active: Tab;
  onChange: (tab: Tab) => void;
}

/* ─── Tab icons ─────────────────────────────────────────────── */
function HomeIcon({ active }: { active: boolean }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      {active ? (
        // Filled home
        <path
          d="M3 12L5 10M5 10L12 3L19 10M5 10V20C5 20.552 5.448 21 6 21H9V15H15V21H18C18.552 21 19 20.552 19 20V10M19 10L21 12"
          stroke="#1A1A1A"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      ) : (
        <path
          d="M3 12L5 10M5 10L12 3L19 10M5 10V20C5 20.552 5.448 21 6 21H9V15H15V21H18C18.552 21 19 20.552 19 20V10M19 10L21 12"
          stroke="#CCCCCC"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      )}
    </svg>
  );
}

function InsightsIcon({ active }: { active: boolean }) {
  const c = active ? "#1A1A1A" : "#CCCCCC";
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <rect x="3" y="12" width="4" height="9" rx="1.2" fill={c} />
      <rect x="10" y="7" width="4" height="14" rx="1.2" fill={c} />
      <rect x="17" y="3" width="4" height="18" rx="1.2" fill={c} />
    </svg>
  );
}

function ScanIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      {/* TL corner */}
      <path d="M3 9V5a2 2 0 0 1 2-2h4" stroke="#1A1A1A" strokeWidth="2" strokeLinecap="round" />
      {/* TR corner */}
      <path d="M15 3h4a2 2 0 0 1 2 2v4" stroke="#1A1A1A" strokeWidth="2" strokeLinecap="round" />
      {/* BL corner */}
      <path d="M3 15v4a2 2 0 0 0 2 2h4" stroke="#1A1A1A" strokeWidth="2" strokeLinecap="round" />
      {/* BR corner */}
      <path d="M15 21h4a2 2 0 0 0 2-2v-4" stroke="#1A1A1A" strokeWidth="2" strokeLinecap="round" />
      {/* Inner grid dots */}
      <rect x="7" y="7" width="3" height="3" rx="0.5" fill="#1A1A1A" />
      <rect x="14" y="7" width="3" height="3" rx="0.5" fill="#1A1A1A" />
      <rect x="7" y="14" width="3" height="3" rx="0.5" fill="#1A1A1A" />
      <rect x="14" y="14" width="3" height="3" rx="0.5" fill="#1A1A1A" />
    </svg>
  );
}

function CardsIcon({ active }: { active: boolean }) {
  const c = active ? "#1A1A1A" : "#CCCCCC";
  const sw = active ? 2 : 1.7;
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <rect x="2" y="6" width="20" height="14" rx="3" stroke={c} strokeWidth={sw} />
      <path d="M2 10h20" stroke={c} strokeWidth={sw} />
      <rect x="5" y="14" width="5" height="2" rx="1" fill={c} />
    </svg>
  );
}

function ProfileIcon({ active }: { active: boolean }) {
  const c = active ? "#1A1A1A" : "#CCCCCC";
  const sw = active ? 2 : 1.7;
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="8" r="4" stroke={c} strokeWidth={sw} />
      <path
        d="M4 20c0-3.314 3.582-6 8-6s8 2.686 8 6"
        stroke={c}
        strokeWidth={sw}
        strokeLinecap="round"
      />
    </svg>
  );
}

/* ─── Bottom Nav ────────────────────────────────────────────── */
const TABS: { id: Tab; label: string }[] = [
  { id: "home", label: "Home" },
  { id: "insights", label: "Insights" },
  { id: "scan", label: "" },
  { id: "cards", label: "My Cards" },
  { id: "profile", label: "Profile" },
];

export function BottomNav({ active, onChange }: BottomNavProps) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-around",
        paddingTop: 10,
        paddingBottom: 26,
        paddingLeft: 4,
        paddingRight: 4,
        background: "#FFFFFF",
        borderTop: "1px solid rgba(0,0,0,0.07)",
      }}
    >
      {TABS.map((tab) => {
        const isActive = active === tab.id;

        /* Center QR scan button */
        if (tab.id === "scan") {
          return (
            <button
              key={tab.id}
              onClick={() => onChange(tab.id)}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                background: "none",
                border: "none",
                padding: 0,
                cursor: "pointer",
                marginTop: -20,
              }}
            >
              <motion.div
                whileTap={{ scale: 0.88 }}
                whileHover={{ scale: 1.06 }}
                style={{
                  width: 58,
                  height: 58,
                  borderRadius: "50%",
                  background: "#C9FF00",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  boxShadow: "0 6px 20px rgba(201,255,0,0.5)",
                }}
              >
                <ScanIcon />
              </motion.div>
            </button>
          );
        }

        return (
          <motion.button
            key={tab.id}
            onClick={() => onChange(tab.id)}
            whileTap={{ scale: 0.9 }}
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: 4,
              background: "none",
              border: "none",
              padding: "0 10px",
              cursor: "pointer",
              minWidth: 52,
            }}
          >
            {tab.id === "home" && <HomeIcon active={isActive} />}
            {tab.id === "insights" && <InsightsIcon active={isActive} />}
            {tab.id === "cards" && <CardsIcon active={isActive} />}
            {tab.id === "profile" && <ProfileIcon active={isActive} />}
            <span
              style={{
                fontSize: 11,
                fontWeight: isActive ? 700 : 400,
                color: isActive ? "#1A1A1A" : "#CCCCCC",
                letterSpacing: -0.1,
              }}
            >
              {tab.label}
            </span>
          </motion.button>
        );
      })}
    </div>
  );
}
