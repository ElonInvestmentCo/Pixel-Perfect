import { motion } from "motion/react";

export function CardsScreen() {
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", overflowY: "auto", background: "#FFFFFF" }}>
      <div style={{ padding: "16px 20px 12px" }}>
        <p style={{ margin: 0, fontSize: 22, fontWeight: 800, color: "#1A1A1A" }}>My Cards</p>
      </div>

      {/* Virtual card */}
      <div style={{ padding: "8px 20px" }}>
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          style={{
            borderRadius: 24,
            background: "linear-gradient(135deg, #5B3EFF 0%, #8B6EFF 100%)",
            padding: "28px 24px",
            position: "relative",
            overflow: "hidden",
            boxShadow: "0 12px 40px rgba(91,62,255,0.3)",
          }}>
          <div style={{ position: "absolute", right: -30, top: -30, width: 160, height: 160, borderRadius: "50%", background: "rgba(255,255,255,0.08)" }} />
          <div style={{ position: "absolute", right: 20, bottom: -50, width: 120, height: 120, borderRadius: "50%", background: "rgba(255,255,255,0.05)" }} />
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 36 }}>
            <span style={{ color: "#fff", fontSize: 16, fontWeight: 700, opacity: 0.9 }}>Visa Platinum</span>
            <svg width="48" height="32" viewBox="0 0 48 32" fill="none">
              <circle cx="18" cy="16" r="14" fill="#FF7262" opacity="0.9"/>
              <circle cx="30" cy="16" r="14" fill="#FF3B30" opacity="0.7"/>
            </svg>
          </div>
          <p style={{ color: "#fff", fontSize: 20, fontWeight: 700, letterSpacing: 4, margin: "0 0 24px", fontFamily: "monospace" }}>•••• •••• •••• 4892</p>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <div>
              <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 10, margin: 0, textTransform: "uppercase", letterSpacing: 1 }}>Card Holder</p>
              <p style={{ color: "#fff", fontSize: 14, fontWeight: 600, margin: "4px 0 0" }}>Jennifer Lopez</p>
            </div>
            <div>
              <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 10, margin: 0, textTransform: "uppercase", letterSpacing: 1 }}>Expires</p>
              <p style={{ color: "#fff", fontSize: 14, fontWeight: 600, margin: "4px 0 0" }}>09/28</p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Add card button */}
      <div style={{ padding: "16px 20px" }}>
        <motion.button
          whileTap={{ scale: 0.97 }}
          style={{
            width: "100%", padding: "16px", borderRadius: 16,
            border: "2px dashed #E5E7EB", background: "none", cursor: "pointer",
            display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
          }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M12 5V19M5 12H19" stroke="#9CA3AF" strokeWidth="2.5" strokeLinecap="round"/>
          </svg>
          <span style={{ fontSize: 15, fontWeight: 600, color: "#9CA3AF" }}>Add New Card</span>
        </motion.button>
      </div>

      {/* Card details */}
      <div style={{ padding: "8px 20px" }}>
        <p style={{ margin: "0 0 14px", fontSize: 18, fontWeight: 700, color: "#1A1A1A" }}>Card Details</p>
        {[
          { label: "Available Balance", value: "$8,240.00", highlight: true },
          { label: "Credit Limit", value: "$15,000.00" },
          { label: "Due Date", value: "June 28, 2026" },
          { label: "Minimum Payment", value: "$120.00" },
        ].map((item) => (
          <div key={item.label} style={{ display: "flex", justifyContent: "space-between", padding: "14px 0", borderBottom: "1px solid rgba(0,0,0,0.06)" }}>
            <span style={{ fontSize: 14, color: "#9CA3AF" }}>{item.label}</span>
            <span style={{ fontSize: 14, fontWeight: 700, color: item.highlight ? "#5B3EFF" : "#1A1A1A" }}>{item.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
