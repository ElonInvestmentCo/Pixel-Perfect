import { motion } from "motion/react";
import { InviteBanner } from "./InviteBanner";

const AVATAR =
  "https://images.unsplash.com/photo-1644718847160-52a922094f69?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMHdvbWFuJTIwcG9ydHJhaXQlMjBhdmF0YXIlMjBwcm9maWxlfGVufDF8fHx8MTc4MDkzMDk0M3ww&ixlib=rb-4.1.0&q=80&w=400";

/* ─── SVG icons ─────────────────────────────────────────────── */

function BellIcon() {
  return (
    <svg width="22" height="24" viewBox="0 0 22 24" fill="none">
      <path
        d="M11 2C7.134 2 4 5.134 4 9v6l-2 2v1h18v-1l-2-2V9c0-3.866-3.134-7-7-7Z"
        stroke="#1A1A1A"
        strokeWidth="1.7"
        strokeLinejoin="round"
        fill="none"
      />
      <path
        d="M8.5 20c0 1.381 1.119 2.5 2.5 2.5s2.5-1.119 2.5-2.5"
        stroke="#1A1A1A"
        strokeWidth="1.7"
        strokeLinecap="round"
        fill="none"
      />
    </svg>
  );
}

function EyeIcon() {
  return (
    <svg width="18" height="14" viewBox="0 0 22 16" fill="none">
      <path
        d="M1 8s3.636-7 10-7S21 8 21 8s-3.636 7-10 7S1 8 1 8Z"
        stroke="#ABABAB"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="11" cy="8" r="3" stroke="#ABABAB" strokeWidth="1.8" />
    </svg>
  );
}

function ArrowUpIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
      <path
        d="M12 20V4M5 11l7-7 7 7"
        stroke="#1A1A1A"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function ArrowDownIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
      <path
        d="M12 4v16M19 13l-7 7-7-7"
        stroke="#1A1A1A"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function HamburgerIcon() {
  return (
    <svg width="18" height="13" viewBox="0 0 18 13" fill="none">
      <path d="M0 1.5h18M0 6.5h18M0 11.5h18" stroke="#1A1A1A" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

/* ── Transaction icons ── */
function FigmaLogo() {
  return (
    <svg width="23" height="34" viewBox="0 0 38 57" fill="none">
      <path d="M19 28.5a8.5 8.5 0 1 1 17 0 8.5 8.5 0 0 1-17 0Z" fill="#1ABCFE" />
      <path d="M2 47.5a8.5 8.5 0 0 1 8.5-8.5H19v8.5a8.5 8.5 0 0 1-17 0Z" fill="#0ACF83" />
      <path d="M19 1v18.5h8.5a8.5 8.5 0 0 0 0-17L19 1Z" fill="#FF7262" />
      <path d="M2 10.5a8.5 8.5 0 0 1 8.5-8.5H19v17H10.5A8.5 8.5 0 0 1 2 10.5Z" fill="#F24E1E" />
      <path d="M2 29a8.5 8.5 0 0 1 8.5-8.5H19V37H10.5A8.5 8.5 0 0 1 2 29Z" fill="#FF7262" />
    </svg>
  );
}

function TxArrowDown() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <path d="M12 4v16M19 13l-7 7-7-7" stroke="#1A1A1A" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function MediumLogo() {
  return (
    <svg width="28" height="16" viewBox="0 0 28 16" fill="none">
      <ellipse cx="7.5" cy="8" rx="7.5" ry="8" fill="#1A1A1A" />
      <ellipse cx="20" cy="8" rx="4" ry="7" fill="#1A1A1A" />
      <ellipse cx="26" cy="8" rx="2" ry="6.5" fill="#1A1A1A" />
    </svg>
  );
}

/* ─── Action Button ─────────────────────────────────────────── */
interface ActionBtnProps {
  icon: React.ReactNode;
  label: string;
  circle?: boolean;
}

function ActionButton({ icon, label, circle }: ActionBtnProps) {
  if (circle) {
    return (
      <motion.button
        whileTap={{ scale: 0.92 }}
        whileHover={{ scale: 1.04 }}
        style={{
          width: 52,
          height: 52,
          borderRadius: "50%",
          background: "#C9FF00",
          border: "none",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: "pointer",
          flexShrink: 0,
          boxShadow: "0 2px 8px rgba(201,255,0,0.35)",
        }}
      >
        {icon}
      </motion.button>
    );
  }

  return (
    <motion.button
      whileTap={{ scale: 0.95 }}
      whileHover={{ scale: 1.02 }}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 10,
        background: "#C9FF00",
        border: "none",
        borderRadius: 50,
        padding: "0 20px 0 8px",
        height: 52,
        cursor: "pointer",
        flexShrink: 0,
        boxShadow: "0 2px 8px rgba(201,255,0,0.35)",
      }}
    >
      {/* Circular ring around icon */}
      <div
        style={{
          width: 36,
          height: 36,
          borderRadius: "50%",
          border: "2px solid rgba(0,0,0,0.18)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {icon}
      </div>
      <span style={{ fontSize: 15, fontWeight: 700, color: "#1A1A1A", letterSpacing: -0.2 }}>
        {label}
      </span>
    </motion.button>
  );
}

/* ─── Transaction Row ───────────────────────────────────────── */
interface TxRowProps {
  iconBg: string;
  icon: React.ReactNode;
  name: string;
  date: string;
  amount: string;
  category: string;
  positive: boolean;
  delay: number;
}

function TxRow({ iconBg, icon, name, date, amount, category, positive, delay }: TxRowProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.32, delay, ease: "easeOut" }}
      whileTap={{ scale: 0.985 }}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 14,
        background: "#FFFFFF",
        borderRadius: 18,
        padding: "13px 16px",
        cursor: "pointer",
        border: "1.5px solid rgba(0,0,0,0.07)",
        boxShadow: "0 1px 4px rgba(0,0,0,0.04)",
      }}
    >
      {/* Icon bubble */}
      <div
        style={{
          width: 50,
          height: 50,
          borderRadius: "50%",
          background: iconBg,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
        }}
      >
        {icon}
      </div>

      {/* Name + date */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{ margin: 0, fontSize: 15, fontWeight: 600, color: "#1A1A1A", letterSpacing: -0.1 }}>
          {name}
        </p>
        <p style={{ margin: "3px 0 0", fontSize: 12, color: "#ABABAB", fontWeight: 400 }}>{date}</p>
      </div>

      {/* Amount + category */}
      <div style={{ textAlign: "right", flexShrink: 0 }}>
        <p
          style={{
            margin: 0,
            fontSize: 15,
            fontWeight: 700,
            color: positive ? "#1A1A1A" : "#1A1A1A",
            letterSpacing: -0.3,
          }}
        >
          {amount}
        </p>
        <p style={{ margin: "3px 0 0", fontSize: 11, color: "#ABABAB", fontWeight: 400 }}>
          {category}
        </p>
      </div>
    </motion.div>
  );
}

/* ─── Home Screen ───────────────────────────────────────────── */
export function HomeScreen() {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100%",
        overflowY: "auto",
        overflowX: "hidden",
        background: "#FFFFFF",
      }}
    >
      {/* ── Header ── */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "14px 22px 10px",
        }}
      >
        {/* Avatar + greeting */}
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div
            style={{
              width: 46,
              height: 46,
              borderRadius: "50%",
              overflow: "hidden",
              flexShrink: 0,
              border: "2px solid #E8E8E8",
            }}
          >
            <img
              src={AVATAR}
              alt="Jennifer"
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
            />
          </div>
          <div>
            <p
              style={{
                fontSize: 16,
                fontWeight: 700,
                color: "#1A1A1A",
                margin: 0,
                lineHeight: 1.25,
                letterSpacing: -0.2,
              }}
            >
              Hi, Jennifer
            </p>
            <p
              style={{
                fontSize: 13,
                color: "#ABABAB",
                margin: "2px 0 0",
                lineHeight: 1.2,
                fontWeight: 400,
              }}
            >
              Good Morning!
            </p>
          </div>
        </div>

        {/* Bell */}
        <motion.button
          whileTap={{ scale: 0.88 }}
          style={{
            position: "relative",
            background: "none",
            border: "none",
            padding: 6,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <BellIcon />
          {/* Red badge */}
          <div
            style={{
              position: "absolute",
              top: 4,
              right: 4,
              width: 9,
              height: 9,
              borderRadius: "50%",
              background: "#FF3B30",
              border: "1.5px solid #FFFFFF",
            }}
          />
        </motion.button>
      </div>

      {/* ── Balance ── */}
      <div style={{ padding: "12px 22px 0" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
          <span
            style={{
              fontSize: 13,
              color: "#ABABAB",
              fontWeight: 400,
              letterSpacing: 0.1,
            }}
          >
            Total Balance
          </span>
          <EyeIcon />
        </div>
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: "easeOut" }}
          style={{
            fontSize: 42,
            fontWeight: 800,
            color: "#1A1A1A",
            margin: 0,
            letterSpacing: -2,
            lineHeight: 1.05,
          }}
        >
          $12,765.00
        </motion.p>
      </div>

      {/* ── Action Buttons ── */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.1 }}
        style={{
          display: "flex",
          alignItems: "center",
          gap: 10,
          padding: "20px 22px 0",
        }}
      >
        <ActionButton icon={<ArrowUpIcon />} label="Transfer" />
        <ActionButton icon={<ArrowDownIcon />} label="Receive" />
        <ActionButton icon={<HamburgerIcon />} label="" circle />
      </motion.div>

      {/* ── Invite Banner ── */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.18 }}
        style={{ marginTop: 22, marginBottom: 24 }}
      >
        <InviteBanner />
      </motion.div>

      {/* ── Transactions ── */}
      <div style={{ padding: "0 22px", paddingBottom: 16 }}>
        {/* Header row */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 14,
          }}
        >
          <span
            style={{
              fontSize: 19,
              fontWeight: 800,
              color: "#1A1A1A",
              letterSpacing: -0.4,
            }}
          >
            Transactions
          </span>
          <motion.span
            whileTap={{ scale: 0.94 }}
            style={{
              fontSize: 14,
              fontWeight: 600,
              color: "#5B3EFF",
              cursor: "pointer",
            }}
          >
            See All
          </motion.span>
        </div>

        {/* Transaction list */}
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <TxRow
            delay={0.22}
            iconBg="#EDE8FF"
            icon={<FigmaLogo />}
            name="Figma"
            date="Today, 12:30 PM"
            amount="-$250.00"
            category="Subscriptions"
            positive={false}
          />
          <TxRow
            delay={0.3}
            iconBg="#DCFF7A"
            icon={<TxArrowDown />}
            name="Receive from Alex"
            date="Yesterday, 08:00 AM"
            amount="+$580.00"
            category="Money In"
            positive={true}
          />
          <TxRow
            delay={0.38}
            iconBg="#FFF3C0"
            icon={<MediumLogo />}
            name="Medium"
            date="May 10, 06:00 PM"
            amount="-$99.00"
            category="Subscriptions"
            positive={false}
          />
        </div>
      </div>
    </div>
  );
}
