import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const monthlyData = [
  { month: "Jan", spent: 1200 },
  { month: "Feb", spent: 980 },
  { month: "Mar", spent: 1450 },
  { month: "Apr", spent: 860 },
  { month: "May", spent: 1640 },
  { month: "Jun", spent: 1100 },
];

const categories = [
  { label: "Subscriptions", amount: "$349", pct: 28, color: "#5B3EFF" },
  { label: "Food & Drink", amount: "$620", pct: 48, color: "#C8FF00" },
  { label: "Transport", amount: "$180", pct: 14, color: "#FF7262" },
  { label: "Shopping", amount: "$130", pct: 10, color: "#1ABCFE" },
];

export function InsightsScreen() {
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", overflowY: "auto", background: "#FFFFFF" }}>
      <div style={{ padding: "16px 20px 12px" }}>
        <p style={{ margin: 0, fontSize: 22, fontWeight: 800, color: "#1A1A1A" }}>Insights</p>
        <p style={{ margin: "4px 0 0", fontSize: 13, color: "#9CA3AF" }}>June 2026</p>
      </div>

      {/* Monthly spending chart */}
      <div style={{ margin: "8px 20px", background: "#FAFAFA", borderRadius: 20, padding: "20px 16px 12px", border: "1px solid rgba(0,0,0,0.05)" }}>
        <p style={{ margin: "0 0 4px", fontSize: 13, color: "#9CA3AF" }}>Monthly Spending</p>
        <p style={{ margin: "0 0 16px", fontSize: 28, fontWeight: 800, color: "#1A1A1A" }}>$6,230</p>
        <ResponsiveContainer width="100%" height={140}>
          <BarChart data={monthlyData} barSize={28}>
            <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: "#9CA3AF" }} />
            <YAxis hide />
            <Tooltip
              contentStyle={{ background: "#1A1A1A", border: "none", borderRadius: 8, color: "#fff", fontSize: 12 }}
              cursor={{ fill: "rgba(0,0,0,0.04)", radius: 6 }}
            />
            <Bar dataKey="spent" fill="#C8FF00" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Categories */}
      <div style={{ padding: "20px 20px 0" }}>
        <p style={{ margin: "0 0 14px", fontSize: 18, fontWeight: 700, color: "#1A1A1A" }}>By Category</p>
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {categories.map((cat) => (
            <div key={cat.label}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                <span style={{ fontSize: 14, fontWeight: 500, color: "#1A1A1A" }}>{cat.label}</span>
                <span style={{ fontSize: 14, fontWeight: 700, color: "#1A1A1A" }}>{cat.amount}</span>
              </div>
              <div style={{ height: 8, background: "#F3F4F6", borderRadius: 4, overflow: "hidden" }}>
                <div style={{ height: "100%", width: `${cat.pct}%`, background: cat.color, borderRadius: 4, transition: "width 0.6s ease" }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
