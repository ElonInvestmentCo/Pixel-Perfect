import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { StatusBar } from "./components/StatusBar";
import { BottomNav } from "./components/BottomNav";
import { HomeScreen } from "./components/HomeScreen";
import { ProfileScreen } from "./components/ProfileScreen";
import { InsightsScreen } from "./components/InsightsScreen";
import { CardsScreen } from "./components/CardsScreen";

type Tab = "home" | "insights" | "scan" | "cards" | "profile";

const tabOrder: Tab[] = ["home", "insights", "scan", "cards", "profile"];

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [prevTab, setPrevTab] = useState<Tab>("home");

  function handleChange(tab: Tab) {
    setPrevTab(activeTab);
    setActiveTab(tab);
  }

  const prevIdx = tabOrder.indexOf(prevTab);
  const activeIdx = tabOrder.indexOf(activeTab);
  const dir = activeIdx >= prevIdx ? 1 : -1;

  const screenMap: Record<Tab, React.ReactNode> = {
    home: <HomeScreen />,
    insights: <InsightsScreen />,
    scan: <HomeScreen />,
    cards: <CardsScreen />,
    profile: <ProfileScreen onBack={() => handleChange("home")} />,
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "linear-gradient(145deg, #EAE4FF 0%, #F5F2FF 40%, #E8F5E0 100%)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "20px 16px",
      }}
    >
      {/* ── Phone shell ── */}
      <div
        style={{
          width: "100%",
          maxWidth: 393,
          height: "min(852px, calc(100vh - 40px))",
          background: "#FFFFFF",
          borderRadius: 54,
          overflow: "hidden",
          boxShadow:
            "0 40px 100px rgba(0,0,0,0.22), 0 0 0 1px rgba(0,0,0,0.07), inset 0 0 0 1.5px rgba(255,255,255,0.7)",
          display: "flex",
          flexDirection: "column",
          position: "relative",
        }}
      >
        {/* Status bar */}
        <StatusBar />

        {/* Scrollable content area */}
        <div style={{ flex: 1, position: "relative", overflow: "hidden" }}>
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: dir * 28 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: dir * -28 }}
              transition={{ duration: 0.2, ease: [0.32, 0.72, 0, 1] }}
              style={{ position: "absolute", inset: 0 }}
            >
              {screenMap[activeTab]}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Bottom navigation */}
        <BottomNav active={activeTab} onChange={handleChange} />

        {/* Home indicator pill */}
        <div
          style={{
            position: "absolute",
            bottom: 6,
            left: "50%",
            transform: "translateX(-50%)",
            width: 130,
            height: 5,
            borderRadius: 3,
            background: "rgba(0,0,0,0.18)",
          }}
        />
      </div>
    </div>
  );
}
