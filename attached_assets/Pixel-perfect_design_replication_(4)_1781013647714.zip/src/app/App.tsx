import { useState } from "react";
import { motion } from "motion/react";

function CoinIllustration() {
  return (
    <div className="relative flex items-center justify-center" style={{ width: 260, height: 240 }}>
      {/* Pedestal platform - light blue/gray 3D effect */}
      <svg
        width="260"
        height="240"
        viewBox="0 0 260 240"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        style={{ position: "absolute", top: 0, left: 0 }}
      >
        {/* Platform shadow/glow */}
        <ellipse cx="130" cy="210" rx="85" ry="18" fill="rgba(180,195,220,0.35)" />

        {/* Platform top face */}
        <ellipse cx="130" cy="168" rx="80" ry="32" fill="#dce8f5" />

        {/* Platform front-right face */}
        <path d="M210 168 L210 198 Q130 218 50 198 L50 168 Q130 188 210 168Z" fill="#b8cfe8" />

        {/* Platform front-left face */}
        <path d="M50 168 L50 198 Q130 218 130 218 L130 188 Q90 178 50 168Z" fill="#c8daf0" />

        {/* Platform highlight on top edge */}
        <ellipse cx="130" cy="168" rx="80" ry="32" fill="none" stroke="rgba(255,255,255,0.7)" strokeWidth="1.5" />

        {/* --- Coins --- */}

        {/* Back coin (silver/gray) - top right */}
        {/* Shadow */}
        <ellipse cx="162" cy="128" rx="38" ry="14" fill="rgba(120,140,170,0.25)" />
        {/* Coin body */}
        <ellipse cx="162" cy="112" rx="38" ry="38" fill="url(#silverGrad)" />
        {/* Coin rim */}
        <ellipse cx="162" cy="112" rx="38" ry="38" fill="none" stroke="#b0bec5" strokeWidth="1" />
        {/* Coin face detail */}
        <ellipse cx="162" cy="112" rx="29" ry="29" fill="none" stroke="rgba(255,255,255,0.5)" strokeWidth="1.5" />
        {/* B symbol */}
        <text x="162" y="118" textAnchor="middle" fill="rgba(255,255,255,0.8)" fontSize="22" fontWeight="bold" fontFamily="Arial">₿</text>

        {/* Middle coin (gold) - center */}
        {/* Shadow */}
        <ellipse cx="130" cy="140" rx="42" ry="15" fill="rgba(180,130,0,0.2)" />
        {/* Coin body */}
        <ellipse cx="130" cy="122" rx="42" ry="42" fill="url(#goldGrad)" />
        {/* Coin rim */}
        <ellipse cx="130" cy="122" rx="42" ry="42" fill="none" stroke="#c8860a" strokeWidth="1.5" />
        {/* Inner circle */}
        <ellipse cx="130" cy="122" rx="33" ry="33" fill="none" stroke="rgba(255,220,100,0.6)" strokeWidth="2" />
        {/* B symbol */}
        <text x="130" y="129" textAnchor="middle" fill="rgba(255,255,255,0.95)" fontSize="26" fontWeight="bold" fontFamily="Arial">₿</text>

        {/* Front-left coin (gold) - slightly lower */}
        {/* Shadow */}
        <ellipse cx="100" cy="146" rx="36" ry="13" fill="rgba(180,130,0,0.2)" />
        {/* Coin body */}
        <ellipse cx="100" cy="130" rx="36" ry="36" fill="url(#goldGrad2)" />
        {/* Coin rim */}
        <ellipse cx="100" cy="130" rx="36" ry="36" fill="none" stroke="#c8860a" strokeWidth="1.5" />
        {/* Inner circle */}
        <ellipse cx="100" cy="130" rx="28" ry="28" fill="none" stroke="rgba(255,220,100,0.6)" strokeWidth="1.5" />
        {/* B symbol */}
        <text x="100" y="137" textAnchor="middle" fill="rgba(255,255,255,0.9)" fontSize="22" fontWeight="bold" fontFamily="Arial">₿</text>

        {/* Gradients */}
        <defs>
          <radialGradient id="goldGrad" cx="38%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#ffe07a" />
            <stop offset="40%" stopColor="#f4a800" />
            <stop offset="100%" stopColor="#b87000" />
          </radialGradient>
          <radialGradient id="goldGrad2" cx="38%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#ffd966" />
            <stop offset="40%" stopColor="#eda800" />
            <stop offset="100%" stopColor="#a06000" />
          </radialGradient>
          <radialGradient id="silverGrad" cx="38%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#e8eef5" />
            <stop offset="40%" stopColor="#b0bec5" />
            <stop offset="100%" stopColor="#78909c" />
          </radialGradient>
        </defs>
      </svg>
    </div>
  );
}

const slides = [
  {
    title: "Buying & Selling",
    subtitle: "Buy and sell cryptocurrencies with popular payment solutions",
  },
  {
    title: "Secure Wallet",
    subtitle: "Keep your assets safe with military-grade encryption technology",
  },
  {
    title: "Fast Transfers",
    subtitle: "Send and receive crypto instantly anywhere in the world",
  },
  {
    title: "Track Portfolio",
    subtitle: "Monitor your investments with real-time price updates and charts",
  },
];

export default function App() {
  const [activeSlide, setActiveSlide] = useState(0);

  return (
    <div
      className="size-full flex items-center justify-center"
      style={{ background: "#f0f2f5", minHeight: "100vh" }}
    >
      {/* Phone frame — iPhone 16 Pro Max */}
      <div
        style={{
          width: 430,
          height: 932,
          background: "#ffffff",
          borderRadius: 54,
          boxShadow:
            "0 0 0 11px #1a1a1a, 0 0 0 13px #2e2e2e, 0 40px 100px rgba(0,0,0,0.4), 0 10px 30px rgba(0,0,0,0.2)",
          position: "relative",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
        }}
      >
        {/* Dynamic Island */}
        <div
          style={{
            position: "absolute",
            top: 14,
            left: "50%",
            transform: "translateX(-50%)",
            width: 126,
            height: 37,
            background: "#1a1a1a",
            borderRadius: 20,
            zIndex: 10,
          }}
        />

        {/* Spacer for Dynamic Island */}
        <div style={{ height: 60 }} />

        {/* Skip button */}
        <div style={{ padding: "4px 28px 0" }}>
          <button
            onClick={() => setActiveSlide(slides.length - 1)}
            style={{
              fontSize: 16,
              color: "#555",
              background: "none",
              border: "none",
              cursor: "pointer",
              padding: 0,
              fontFamily: "inherit",
            }}
          >
            Skip
          </button>
        </div>

        {/* Main illustration area */}
        <div
          style={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "flex-end",
            paddingBottom: 20,
          }}
        >
          <motion.div
            key={activeSlide}
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
          >
            <CoinIllustration />
          </motion.div>
        </div>

        {/* Bottom content card - white rounded section */}
        <div
          style={{
            background: "#ffffff",
            padding: "32px 32px 40px",
            borderTop: "none",
          }}
        >
          {/* Pagination dots */}
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              gap: 8,
              marginBottom: 28,
            }}
          >
            {slides.map((_, i) => (
              <button
                key={i}
                onClick={() => setActiveSlide(i)}
                style={{
                  width: i === activeSlide ? 24 : 8,
                  height: 8,
                  borderRadius: 4,
                  background: i === activeSlide ? "#111111" : "#d0d0d8",
                  border: "none",
                  cursor: "pointer",
                  padding: 0,
                  transition: "all 0.3s ease",
                }}
              />
            ))}
          </div>

          {/* Title */}
          <motion.h1
            key={`title-${activeSlide}`}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35 }}
            style={{
              fontSize: 28,
              fontWeight: 700,
              color: "#111111",
              textAlign: "center",
              margin: "0 0 12px",
              lineHeight: 1.25,
              letterSpacing: "-0.5px",
            }}
          >
            {slides[activeSlide].title}
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            key={`sub-${activeSlide}`}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: 0.05 }}
            style={{
              fontSize: 15,
              color: "#888",
              textAlign: "center",
              margin: "0 0 32px",
              lineHeight: 1.6,
              letterSpacing: "0.1px",
            }}
          >
            {slides[activeSlide].subtitle}
          </motion.p>

          {/* CTA Button */}
          <motion.button
            whileTap={{ scale: 0.97 }}
            whileHover={{ brightness: 1.05 }}
            onClick={() =>
              activeSlide < slides.length - 1
                ? setActiveSlide((s) => s + 1)
                : alert("Wallet creation flow!")
            }
            style={{
              width: "100%",
              padding: "18px 0",
              borderRadius: 50,
              background: "#c6f135",
              border: "none",
              cursor: "pointer",
              fontSize: 16,
              fontWeight: 700,
              color: "#111111",
              letterSpacing: "0.1px",
              boxShadow: "0 4px 20px rgba(180,230,0,0.35)",
              transition: "transform 0.15s ease, box-shadow 0.15s ease",
              fontFamily: "inherit",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLButtonElement).style.boxShadow =
                "0 6px 28px rgba(180,230,0,0.5)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLButtonElement).style.boxShadow =
                "0 4px 20px rgba(180,230,0,0.35)";
            }}
          >
            Create a new wallet
          </motion.button>

          {/* Bottom safe area spacer */}
          <div style={{ height: 8 }} />
        </div>
      </div>
    </div>
  );
}
