import { useState } from "react";
import { ArrowUp, ArrowDown, AlignJustify, Eye, EyeOff } from "lucide-react";

export default function App() {
  return (
    <div className="size-full flex items-center justify-center" style={{ background: "#f0f0f0" }}>
      {/* MARKER-MAKE-KIT-INVOKED */}
      <BalanceCard />
    </div>
  );
}

function BalanceCard() {
  const [visible, setVisible] = useState(true);

  return (
    <div
      style={{
        width: "min(320px, calc(100vw - 32px))",
        background: "#ffffff",
        borderRadius: 20,
        padding: "24px 24px 20px",
        boxShadow: "0 4px 24px rgba(0,0,0,0.10)",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Faint circular watermark */}
      <div
        style={{
          position: "absolute",
          width: 200,
          height: 200,
          borderRadius: "50%",
          border: "28px solid rgba(0,0,0,0.04)",
          top: "50%",
          left: "50%",
          transform: "translate(-30%, -50%)",
          pointerEvents: "none",
        }}
      />

      {/* Label row */}
      <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
        <span style={{ fontSize: 13, color: "#888", fontWeight: 400 }}>Total Balance</span>
        <button
          onClick={() => setVisible(v => !v)}
          style={{
            background: "none",
            border: "none",
            padding: 0,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            color: "#aaa",
            transition: "color 0.15s",
          }}
          onMouseEnter={e => (e.currentTarget.style.color = "#555")}
          onMouseLeave={e => (e.currentTarget.style.color = "#aaa")}
          aria-label={visible ? "Hide balance" : "Show balance"}
        >
          {visible ? <Eye size={14} /> : <EyeOff size={14} />}
        </button>
      </div>

      {/* Balance amount */}
      <div
        style={{
          fontSize: 36,
          fontWeight: 700,
          color: "#111",
          letterSpacing: "-0.5px",
          marginBottom: 20,
          lineHeight: 1.15,
          minHeight: "1.15em",
          transition: "opacity 0.2s",
        }}
      >
        <span style={{ color: visible ? "#bbb" : "#111", fontWeight: visible ? 600 : 700 }}>
        {visible ? "$0.00" : "••••••••"}
      </span>
      </div>

      {/* Action buttons */}
      <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
        <ActionButton icon={<ArrowUp size={13} strokeWidth={2.8} />} label="Transfer" />
        <ActionButton icon={<ArrowDown size={13} strokeWidth={2.8} />} label="Receive" />
        <MenuButton />
      </div>
    </div>
  );
}

function ActionButton({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <button
      style={{
        display: "flex",
        alignItems: "center",
        gap: 8,
        background: "#e8f535",
        border: "2px solid #111",
        borderRadius: 999,
        padding: "5px 14px 5px 5px",
        cursor: "pointer",
        fontWeight: 600,
        fontSize: 14,
        color: "#111",
        transition: "opacity 0.15s",
        lineHeight: 1,
        boxShadow: "0 4px 14px rgba(0,0,0,0.18), 0 1px 4px rgba(0,0,0,0.10)",
      }}
      onMouseEnter={e => (e.currentTarget.style.opacity = "0.82")}
      onMouseLeave={e => (e.currentTarget.style.opacity = "1")}
    >
      {/* White icon circle */}
      <span
        style={{
          width: 28,
          height: 28,
          borderRadius: "50%",
          background: "#ffffff",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
        }}
      >
        {icon}
      </span>
      {label}
    </button>
  );
}

function MenuButton() {
  return (
    <button
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "#e8f535",
        border: "2px solid #111",
        borderRadius: "50%",
        width: 40,
        height: 40,
        cursor: "pointer",
        flexShrink: 0,
        transition: "opacity 0.15s",
        padding: 5,
        boxShadow: "0 4px 14px rgba(0,0,0,0.18), 0 1px 4px rgba(0,0,0,0.10)",
      }}
      onMouseEnter={e => (e.currentTarget.style.opacity = "0.82")}
      onMouseLeave={e => (e.currentTarget.style.opacity = "1")}
    >
      <span
        style={{
          width: "100%",
          height: "100%",
          borderRadius: "50%",
          background: "#ffffff",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
        }}
      >
        <AlignJustify size={14} strokeWidth={2.5} color="#111" />
      </span>
    </button>
  );
}
