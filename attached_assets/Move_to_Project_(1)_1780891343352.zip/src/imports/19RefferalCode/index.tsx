import img19RefferalCode from "./cfcc2b68318854c5267e07b9eb0338ec60fac3ce.png";

export default function Component19RefferalCode() {
  return (
    <div className="relative size-full" data-name="19. Refferal Code">
      <div className="absolute h-[812px] left-0 top-0 w-[375px]" data-name="19. Refferal Code">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={img19RefferalCode} />
      </div>
    </div>
  );
}