import { useState } from "react";
import { X, Copy, Check } from "lucide-react";

export function ReferralCode() {
  const [copied, setCopied] = useState(false);
  const code = "R47865BM";

  function handleCopy() {
    navigator.clipboard.writeText(code).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="relative w-[375px] min-h-[812px] bg-[#5B4FCF] overflow-hidden flex flex-col">
        {/* Close button */}
        <button
          className="absolute top-12 left-5 w-9 h-9 rounded-full bg-white/20 flex items-center justify-center z-10"
          aria-label="Close"
        >
          <X className="w-4 h-4 text-white" />
        </button>

        {/* Top hero section */}
        <div className="flex-1 flex flex-col items-center justify-center pt-20 pb-6 px-6 relative">
          {/* Decorative diamonds */}
          <span className="absolute top-24 right-16 text-black text-2xl select-none">◆</span>
          <span className="absolute top-32 right-8 text-black text-sm select-none">◆</span>
          <span className="absolute top-16 left-24 text-black/30 text-xs select-none">+</span>
          <span className="absolute top-40 right-24 text-black/30 text-xs select-none">+</span>
          <span className="absolute bottom-48 left-12 text-black text-xl select-none">◆</span>
          <span className="absolute bottom-44 left-6 text-black text-xs select-none">◆</span>

          {/* Envelope illustration */}
          <div className="relative mb-8">
            {/* Glow circle */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-44 h-44 rounded-full bg-white/15 blur-md" />
            </div>
            {/* Envelope body */}
            <div className="relative z-10 flex flex-col items-center">
              {/* Letter sticking out */}
              <div className="w-20 h-16 bg-white rounded-t-md flex items-center justify-center shadow-md z-10 mb-[-2px]">
                <span className="text-[#5B4FCF] font-bold" style={{ fontSize: "28px" }}>R.</span>
              </div>
              {/* Envelope */}
              <div className="w-32 h-20 bg-[#C6E600] rounded-b-lg relative flex items-end justify-center overflow-hidden">
                {/* Envelope flap triangles */}
                <div
                  className="absolute top-0 left-0 w-full h-10"
                  style={{
                    background:
                      "linear-gradient(135deg, #b8d600 50%, transparent 50%), linear-gradient(225deg, #b8d600 50%, transparent 50%)",
                    backgroundSize: "50% 100%",
                    backgroundPosition: "left, right",
                    backgroundRepeat: "no-repeat",
                  }}
                />
              </div>
            </div>
          </div>

          <h1 className="text-white font-bold text-center mb-3" style={{ fontSize: "26px" }}>
            Invite and Get $20
          </h1>
          <p className="text-white/70 text-center text-sm leading-snug">
            Invite a friend and both earn cashback.<br />
            When a friend get QPay card
          </p>

          {/* Pill indicator */}
          <div className="mt-5 w-10 h-1 bg-white/40 rounded-full" />
        </div>

        {/* Bottom card */}
        <div className="bg-white rounded-t-3xl px-6 pt-7 pb-10">
          {/* Referral code row */}
          <div className="flex items-center justify-between bg-gray-100 rounded-xl px-4 py-4 mb-4">
            <span className="text-gray-800 font-medium tracking-wide">{code}</span>
            <button
              onClick={handleCopy}
              className="text-gray-500 hover:text-[#5B4FCF] transition-colors"
              aria-label="Copy code"
            >
              {copied ? (
                <Check className="w-5 h-5 text-green-500" />
              ) : (
                <Copy className="w-5 h-5" />
              )}
            </button>
          </div>

          {/* Share button */}
          <button className="w-full bg-[#C6E600] hover:bg-[#b8d600] active:bg-[#a8c400] text-black font-bold rounded-xl py-4 mb-6 transition-colors">
            Share
          </button>

          {/* They get */}
          <div className="mb-4">
            <p className="font-bold text-gray-900 mb-2">They get:</p>
            <div className="flex items-start gap-3">
              <div className="mt-0.5 w-5 h-5 rounded-full border-2 border-gray-300 flex items-center justify-center flex-shrink-0">
                <Check className="w-3 h-3 text-gray-400" />
              </div>
              <p className="text-sm text-gray-600 leading-snug">
                A free transfer up to{" "}
                <span className="text-[#5B4FCF] font-semibold">$1000</span>{" "}
                when they sign up with your link
              </p>
            </div>
          </div>

          {/* You get */}
          <div>
            <p className="font-bold text-gray-900 mb-2">You get:</p>
            <div className="flex items-start gap-3">
              <div className="mt-0.5 w-5 h-5 rounded-full border-2 border-gray-300 flex items-center justify-center flex-shrink-0">
                <Check className="w-3 h-3 text-gray-400" />
              </div>
              <p className="text-sm text-gray-600 leading-snug">
                $120 when 3 friends send over $600 in charges
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
