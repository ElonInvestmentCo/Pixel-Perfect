import { ReferralCode } from "./components/ReferralCode";

export default function App() {
  return <ReferralCode />;
}
