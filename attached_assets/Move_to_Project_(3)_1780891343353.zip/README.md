
  # Move to Project

  This is a code bundle for Move to Project. The original project is available at https://www.figma.com/design/MDeA9Vkcz7jmsjupXDBvi8/Move-to-Project.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  