import img17CreateNewPin from "./4ef3c7e41a883c94ddceb4285595b925c0d0d8ac.png";

export default function Component17CreateNewPin() {
  return (
    <div className="relative size-full" data-name="17. Create New PIN">
      <div className="absolute h-[812px] left-0 top-0 w-[375px]" data-name="17. Create New PIN">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={img17CreateNewPin} />
      </div>
    </div>
  );
}