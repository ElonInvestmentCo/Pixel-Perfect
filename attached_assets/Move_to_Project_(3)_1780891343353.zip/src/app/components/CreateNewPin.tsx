import { useState } from "react";
import { Delete } from "lucide-react";

const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "⌫"];

export function CreateNewPin({ onComplete }: { onComplete?: (pin: string) => void }) {
  const [pin, setPin] = useState<string[]>([]);

  function handleKey(key: string) {
    if (key === "⌫") {
      setPin((p) => p.slice(0, -1));
    } else if (key === "*") {
      // no-op for asterisk
    } else if (pin.length < 4) {
      const next = [...pin, key];
      setPin(next);
      if (next.length === 4) {
        onComplete?.(next.join(""));
      }
    }
  }

  return (
    <div className="flex flex-col items-center justify-between min-h-screen bg-white px-6 pt-14 pb-10 max-w-[375px] mx-auto">
      {/* Close button */}
      <div className="w-full flex items-start">
        <button
          className="w-9 h-9 rounded-full bg-[#f5f5f5] flex items-center justify-center text-gray-500 hover:bg-gray-200 transition-colors"
          aria-label="Close"
        >
          ×
        </button>
      </div>

      {/* Title */}
      <div className="w-full mt-6 mb-10">
        <h1 className="text-[28px] font-bold text-gray-900 leading-tight">Create your PIN</h1>
        <p className="text-sm text-gray-400 mt-1">Set a 4-digit PIN for your QPay card</p>
      </div>

      {/* PIN dots */}
      <div className="flex gap-4 mb-auto">
        {Array.from({ length: 4 }).map((_, i) => {
          const filled = i < pin.length;
          const active = i === pin.length;
          return (
            <div
              key={i}
              className={`w-14 h-14 rounded-2xl flex items-center justify-center text-xl font-semibold transition-all
                ${active ? "border-2 border-gray-800 bg-white shadow-sm" : filled ? "bg-[#f5f5f5]" : "bg-[#f5f5f5]"}`}
            >
              {filled ? (
                <span className="w-3 h-3 rounded-full bg-gray-800 block" />
              ) : active ? (
                <span className="w-0.5 h-6 bg-gray-800 animate-pulse block" />
              ) : null}
            </div>
          );
        })}
      </div>

      {/* Choose PIN button */}
      <button
        onClick={() => pin.length === 4 && onComplete?.(pin.join(""))}
        disabled={pin.length < 4}
        className={`w-full py-4 rounded-2xl text-base font-bold transition-all mt-10 mb-6
          ${pin.length === 4
            ? "bg-[#c6f135] text-gray-900 hover:brightness-95"
            : "bg-[#c6f135] text-gray-900 opacity-70 cursor-not-allowed"}`}
      >
        Choose your PIN
      </button>

      {/* Numpad */}
      <div className="w-full grid grid-cols-3 gap-y-1">
        {KEYS.map((key) => (
          <button
            key={key}
            onClick={() => handleKey(key)}
            className="flex items-center justify-center h-16 text-xl font-medium text-gray-900 rounded-xl hover:bg-gray-100 active:bg-gray-200 transition-colors select-none"
            aria-label={key === "⌫" ? "Delete" : key}
          >
            {key === "⌫" ? <Delete size={22} /> : key}
          </button>
        ))}
      </div>

      {/* Home indicator */}
      <div className="w-32 h-1 bg-gray-300 rounded-full mt-4" />
    </div>
  );
}
