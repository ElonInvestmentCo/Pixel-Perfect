import { CreateNewPin } from "./components/CreateNewPin";

export default function App() {
  function handlePinComplete(pin: string) {
    console.log("PIN set:", pin);
  }

  return (
    <div className="size-full flex items-center justify-center bg-gray-100">
      <CreateNewPin onComplete={handlePinComplete} />
    </div>
  );
}
