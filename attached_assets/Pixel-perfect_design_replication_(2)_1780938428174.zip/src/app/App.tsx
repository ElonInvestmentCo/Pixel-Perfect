import { ChevronLeft, HelpCircle, ChevronRight, CreditCard, Delete } from "lucide-react";
import { useState } from "react";

export default function App() {
  const [amount, setAmount] = useState("1,567.00");

  const handleNumberClick = (num: string) => {
    if (amount === "0.00") {
      setAmount(num + ".00");
    } else {
      const cleanAmount = amount.replace(/,/g, "");
      const [whole, decimal] = cleanAmount.split(".");
      if (whole.length < 7) {
        const newWhole = whole + num;
        setAmount(formatNumber(newWhole) + "." + decimal);
      }
    }
  };

  const handleDelete = () => {
    const cleanAmount = amount.replace(/,/g, "");
    const [whole] = cleanAmount.split(".");
    if (whole.length > 1) {
      const newWhole = whole.slice(0, -1);
      setAmount(formatNumber(newWhole) + ".00");
    } else {
      setAmount("0.00");
    }
  };

  const formatNumber = (num: string) => {
    return num.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };

  return (
    <div className="w-full min-h-screen bg-[#F5F3EF] flex justify-center">
      <div className="w-full max-w-[430px] min-h-screen flex flex-col">
        {/* Header */}
        <div className="w-full bg-gradient-to-b from-[#5856D6] to-[#5856D6] px-6 py-6">
          <div className="flex justify-between items-center">
            <button className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm">
              <ChevronLeft className="w-5 h-5 text-white" strokeWidth={3} />
            </button>
            <h1 className="text-white text-[22px] font-semibold tracking-tight">Top Up Balance</h1>
            <button className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm">
              <HelpCircle className="w-5 h-5 text-white" strokeWidth={2.5} />
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 bg-[#F5F3EF] rounded-t-[32px] -mt-2 px-6 pt-8 pb-6 flex flex-col">
        <h2 className="text-[#6B6B6B] text-[17px] font-normal mb-4">Add Money</h2>

        {/* Amount Input */}
        <div className="bg-white border-[2px] border-black rounded-[20px] px-5 py-5 flex items-center justify-between mb-8">
          <div className="flex items-baseline gap-1">
            <span className="text-[#999999] text-[32px] font-normal">$</span>
            <span className="text-black text-[40px] font-semibold tracking-tight">{amount}</span>
          </div>
          <div className="flex items-center gap-2 bg-[#F5F3EF] rounded-full px-3 py-1.5">
            <div className="w-6 h-4 rounded-sm overflow-hidden">
              <svg viewBox="0 0 36 24" className="w-full h-full">
                <rect fill="#ED2939" width="36" height="24"/>
                <rect fill="#FFFFFF" width="36" height="12"/>
                <path d="M10,12 m-3,0 a3,3 0 1,0 6,0 a3,3 0 1,0 -6,0 M18,6 l-4,12 M14,6 l4,12" stroke="#FFFFFF" strokeWidth="0.8" fill="none"/>
              </svg>
            </div>
            <span className="text-black text-[15px] font-semibold">SGD</span>
          </div>
        </div>

        {/* Spacer */}
        <div className="flex-1"></div>

        {/* Payment Method */}
        <div className="bg-white/60 backdrop-blur-sm rounded-[16px] p-4 flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-[#E8E5FF] rounded-[12px] flex items-center justify-center">
              <CreditCard className="w-6 h-6 text-[#5856D6]" strokeWidth={2} />
            </div>
            <div>
              <div className="text-black text-[17px] font-semibold">Mastercards</div>
              <div className="text-[#999999] text-[15px]">**** 7865</div>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-[#999999]" strokeWidth={2.5} />
        </div>

        {/* Numeric Keypad */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
            <button
              key={num}
              onClick={() => handleNumberClick(num.toString())}
              className="bg-[#E8E8E8] rounded-[16px] h-[68px] flex items-center justify-center text-black text-[28px] font-normal active:bg-[#D0D0D0] transition-colors"
            >
              {num}
            </button>
          ))}
          <button
            className="bg-[#E8E8E8] rounded-[16px] h-[68px] flex items-center justify-center text-black text-[32px] font-normal active:bg-[#D0D0D0] transition-colors"
          >
            *
          </button>
          <button
            onClick={() => handleNumberClick("0")}
            className="bg-[#E8E8E8] rounded-[16px] h-[68px] flex items-center justify-center text-black text-[28px] font-normal active:bg-[#D0D0D0] transition-colors"
          >
            0
          </button>
          <button
            onClick={handleDelete}
            className="bg-[#E8E8E8] rounded-[16px] h-[68px] flex items-center justify-center active:bg-[#D0D0D0] transition-colors"
          >
            <Delete className="w-7 h-7 text-black" strokeWidth={2} />
          </button>
        </div>

        {/* Continue Button */}
        <button className="w-full bg-[#C6FF00] rounded-[16px] h-[60px] flex items-center justify-center text-black text-[20px] font-semibold tracking-tight active:bg-[#B0E600] transition-colors shadow-sm">
          Continue
        </button>
        </div>
      </div>
    </div>
  );
}