
  # Pixel-perfect design replication

  This is a code bundle for Pixel-perfect design replication. The original project is available at https://www.figma.com/design/rSSo1LeTxxB0y7yHNkj2a3/Pixel-perfect-design-replication.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  