import Component16UploadSelfie from "../imports/16UploadSelfie/index";

export default function App() {
  return (
    <div className="size-full flex items-center justify-center bg-black">
      <Component16UploadSelfie />
    </div>
  );
}