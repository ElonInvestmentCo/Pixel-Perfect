import img16UploadSelfie from "./a980fb78d4ccf392a455a7642be2a47d7f8208a4.png";

export default function Component16UploadSelfie() {
  return (
    <div className="relative size-full" data-name="16. Upload - Selfie">
      <div className="absolute h-[812px] left-0 top-0 w-[375px]" data-name="16. Upload - Selfie">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={img16UploadSelfie} />
      </div>
    </div>
  );
}