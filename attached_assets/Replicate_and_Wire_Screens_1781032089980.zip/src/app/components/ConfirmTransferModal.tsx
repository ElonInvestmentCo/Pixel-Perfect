import { useState } from 'react';
import { X } from 'lucide-react';

interface Recipient {
  id: string;
  name: string;
  accountNumber: string;
  cardType: 'VISA' | 'MASTERCARD' | 'CHASE' | 'HSBC';
  avatar: string;
}

interface ConfirmTransferModalProps {
  amount: string;
  recipient: Recipient;
  note: string;
  onClose: () => void;
  onConfirm: () => void;
}

export function ConfirmTransferModal({
  recipient,
  note,
  onClose,
  onConfirm,
}: ConfirmTransferModalProps) {
  const [editableNote, setEditableNote] = useState(note);

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-end z-50 animate-in fade-in duration-200"
      onClick={handleBackdropClick}
    >
      <div className="bg-white rounded-t-[32px] w-full flex flex-col animate-in slide-in-from-bottom duration-300 pb-6">
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-6 pb-5 border-b border-[#E5E5EA]">
          <h2 className="text-black text-[20px] font-semibold">Transfer Money</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#F5F5F7] flex items-center justify-center hover:bg-[#E5E5EA] transition-colors"
          >
            <X className="w-5 h-5 text-[#8E8E93]" strokeWidth={2} />
          </button>
        </div>

        {/* Content */}
        <div className="px-5 pt-5">
          {/* From Section */}
          <div className="mb-5">
            <div className="text-[#8E8E93] text-[13px] font-medium mb-2">From:</div>
            <div className="bg-white rounded-2xl p-4 flex items-center gap-3 border border-[#E5E5EA]">
              <div className="w-10 h-10 rounded-lg bg-[#5B5FEF] flex items-center justify-center">
                <svg width="24" height="20" viewBox="0 0 24 20" fill="none">
                  <rect x="0" y="0" width="24" height="16" rx="2" fill="white"/>
                  <rect x="0" y="6" width="24" height="4" fill="#FF5F00"/>
                </svg>
              </div>
              <div className="flex-1">
                <div className="text-black text-[17px] font-semibold">Mastercards</div>
                <div className="text-[#8E8E93] text-[15px]">**** 7865</div>
              </div>
              <div className="flex items-center gap-[-4px]">
                <div className="w-6 h-6 rounded-full bg-[#EB001B]"></div>
                <div className="w-6 h-6 rounded-full bg-[#FF5F00] -ml-3"></div>
              </div>
            </div>
          </div>

          {/* Transfer To Section */}
          <div className="mb-5">
            <div className="text-[#8E8E93] text-[13px] font-medium mb-2">Transfer to:</div>
            <div className="bg-white rounded-2xl p-4 flex items-center gap-3 border border-[#E5E5EA]">
              <img
                src={recipient.avatar}
                alt={recipient.name}
                className="w-10 h-10 rounded-full object-cover"
              />
              <div className="flex-1">
                <div className="text-black text-[17px] font-semibold">{recipient.name}</div>
                <div className="text-[#8E8E93] text-[15px]">{recipient.accountNumber}</div>
              </div>
              <div className="text-[#1A1F71] text-[16px] font-bold">VISA</div>
            </div>
          </div>

          {/* Note Section */}
          <div className="mb-6">
            <div className="text-[#8E8E93] text-[13px] font-medium mb-2">Note:</div>
            <textarea
              value={editableNote}
              onChange={(e) => setEditableNote(e.target.value)}
              placeholder="Add a note..."
              className="w-full bg-[#F5F5F7] rounded-2xl p-4 min-h-[100px] border border-[#E5E5EA] text-black text-[15px] placeholder:text-[#C7C7CC] outline-none resize-none"
            />
          </div>

          {/* Confirm Button */}
          <button
            onClick={onConfirm}
            className="w-full h-14 bg-[#CDFF00] rounded-2xl text-black text-[18px] font-semibold shadow-lg active:scale-[0.98] transition-transform"
          >
            Confirm Transfer
          </button>
        </div>
      </div>
    </div>
  );
}
