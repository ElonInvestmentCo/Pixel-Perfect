import { useState } from 'react';
import { X, Search } from 'lucide-react';
import { recentPayed, allContacts } from '../App';

interface Recipient {
  id: string;
  name: string;
  accountNumber: string;
  cardType: 'VISA' | 'MASTERCARD' | 'CHASE' | 'HSBC';
  avatar: string;
}

interface ChooseRecipientsModalProps {
  onClose: () => void;
  onSelectRecipient: (recipient: Recipient) => void;
  selectedRecipient: Recipient;
}

export function ChooseRecipientsModal({ onClose, onSelectRecipient }: ChooseRecipientsModalProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const filterRecipients = (recipients: Recipient[]) => {
    if (!searchQuery.trim()) return recipients;
    return recipients.filter(recipient =>
      recipient.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      recipient.accountNumber.includes(searchQuery)
    );
  };

  const filteredRecentPayed = filterRecipients(recentPayed);
  const filteredAllContacts = filterRecipients(allContacts);

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };
  const getCardLogo = (type: string) => {
    switch (type) {
      case 'VISA':
        return <span className="text-[#1A1F71] text-[16px] font-bold">VISA</span>;
      case 'MASTERCARD':
        return (
          <div className="flex items-center gap-[-4px]">
            <div className="w-6 h-6 rounded-full bg-[#EB001B]"></div>
            <div className="w-6 h-6 rounded-full bg-[#FF5F00] -ml-3"></div>
          </div>
        );
      case 'CHASE':
        return <span className="text-[#117ACA] text-[14px] font-bold flex items-center gap-1">CHASE<div className="w-2 h-2 rounded-full bg-[#117ACA]"></div></span>;
      case 'HSBC':
        return <span className="text-[#DB0011] text-[14px] font-bold">HSBC</span>;
      default:
        return null;
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-end z-50 animate-in fade-in duration-200"
      onClick={handleBackdropClick}
    >
      <div className="bg-white rounded-t-[32px] w-full max-h-[85vh] flex flex-col animate-in slide-in-from-bottom duration-300">
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-6 pb-4 border-b border-[#E5E5EA]">
          <h2 className="text-black text-[20px] font-semibold">Choose Recipients</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#F5F5F7] flex items-center justify-center hover:bg-[#E5E5EA] transition-colors"
          >
            <X className="w-5 h-5 text-[#8E8E93]" strokeWidth={2} />
          </button>
        </div>

        {/* Search */}
        <div className="px-5 pt-4 pb-2">
          <div className="bg-[#F5F5F7] rounded-xl px-4 py-3 flex items-center gap-2">
            <Search className="w-5 h-5 text-[#8E8E93]" />
            <input
              type="text"
              placeholder="Search contact"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 bg-transparent text-[17px] text-black placeholder:text-[#8E8E93] outline-none"
            />
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-5 pb-8">
          {/* Recent Payed */}
          {filteredRecentPayed.length > 0 && (
            <div className="mt-4">
              <h3 className="text-black text-[15px] font-semibold mb-3">Recent Payed</h3>
              <div className="space-y-2">
                {filteredRecentPayed.map((recipient) => (
                <button
                  key={recipient.id}
                  onClick={() => onSelectRecipient(recipient)}
                  className="w-full bg-white rounded-2xl p-4 flex items-center gap-3 border border-[#E5E5EA] hover:bg-gray-50 transition-colors"
                >
                  <img
                    src={recipient.avatar}
                    alt={recipient.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div className="flex-1 text-left">
                    <div className="text-black text-[17px] font-semibold">{recipient.name}</div>
                    <div className="text-[#8E8E93] text-[15px]">{recipient.accountNumber}</div>
                  </div>
                  {getCardLogo(recipient.cardType)}
                </button>
              ))}
              </div>
            </div>
          )}

          {/* All Contact */}
          {filteredAllContacts.length > 0 && (
            <div className="mt-6">
              <h3 className="text-black text-[15px] font-semibold mb-3">All Contact</h3>
              <div className="space-y-2">
                {filteredAllContacts.map((recipient) => (
                <button
                  key={recipient.id}
                  onClick={() => onSelectRecipient(recipient)}
                  className="w-full bg-white rounded-2xl p-4 flex items-center gap-3 border border-[#E5E5EA] hover:bg-gray-50 transition-colors"
                >
                  <img
                    src={recipient.avatar}
                    alt={recipient.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div className="flex-1 text-left">
                    <div className="text-black text-[17px] font-semibold">{recipient.name}</div>
                    <div className="text-[#8E8E93] text-[15px]">{recipient.accountNumber}</div>
                  </div>
                  {getCardLogo(recipient.cardType)}
                </button>
              ))}
              </div>
            </div>
          )}

          {/* No Results */}
          {filteredRecentPayed.length === 0 && filteredAllContacts.length === 0 && searchQuery && (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="text-[#8E8E93] text-[17px] mb-2">No contacts found</div>
              <div className="text-[#C7C7CC] text-[15px]">Try searching with a different name or account number</div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
