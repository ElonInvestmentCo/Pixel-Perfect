import { useState } from 'react';
import { ChevronLeft, Shield, Calendar } from 'lucide-react';

interface Recipient {
  id: string;
  name: string;
  accountNumber: string;
  cardType: 'VISA' | 'MASTERCARD' | 'CHASE' | 'HSBC';
  avatar: string;
}

interface TransferScreenProps {
  amount: string;
  recipient: Recipient;
  note: string;
  onRecipientClick: () => void;
  onSendMoney: () => void;
  onAmountChange: (amount: string) => void;
  onNoteChange: (note: string) => void;
}

export function TransferScreen({
  amount,
  recipient,
  note,
  onRecipientClick,
  onSendMoney,
  onNoteChange,
}: TransferScreenProps) {
  const [inputAmount, setInputAmount] = useState(amount);

  const handleNumberClick = (num: string) => {
    if (num === 'delete') {
      setInputAmount(prev => prev.slice(0, -1) || '0.00');
    } else if (num === '.') {
      if (!inputAmount.includes('.')) {
        setInputAmount(prev => prev + '.');
      }
    } else {
      setInputAmount(prev => {
        const newValue = prev === '0.00' ? num : prev + num;
        return newValue;
      });
    }
  };

  return (
    <div className="min-h-screen h-full w-full bg-gradient-to-b from-[#5B5FEF] to-[#6D72FF] flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-5 pt-6 pb-6">
        <button className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
          <ChevronLeft className="w-6 h-6 text-white" strokeWidth={2.5} />
        </button>
        <h1 className="text-white text-[22px] font-semibold">Transfer Money</h1>
        <button className="w-12 h-12 rounded-full bg-[#CDFF00] flex items-center justify-center">
          <Shield className="w-6 h-6 text-black" fill="black" />
        </button>
      </div>

      {/* Main Card */}
      <div className="flex-1 bg-[#F5F5F7] rounded-t-[32px] px-5 pt-12 pb-0 flex flex-col">
        {/* Amount Section */}
        <div className="text-center mb-8">
          <div className="text-[#8E8E93] text-[15px] font-medium mb-2">Enter amount</div>
          <div className="flex items-center justify-center">
            <span className="text-[#8E8E93] text-[56px] font-semibold mr-1">$</span>
            <span className="text-black text-[56px] font-semibold tracking-tight">{inputAmount}</span>
            <span className="w-0.5 h-14 bg-black ml-1 animate-pulse"></span>
          </div>
        </div>

        {/* Recipient Card */}
        <button
          onClick={onRecipientClick}
          className="bg-white rounded-2xl p-4 mb-4 flex items-center gap-3 shadow-sm border border-[#E5E5EA] hover:bg-gray-50 transition-colors"
        >
          <img
            src={recipient.avatar}
            alt={recipient.name}
            className="w-14 h-14 rounded-full object-cover"
          />
          <div className="flex-1 text-left">
            <div className="text-black text-[17px] font-semibold">{recipient.name}</div>
            <div className="text-[#8E8E93] text-[15px]">{recipient.accountNumber}</div>
          </div>
          <div className="text-[#1A1F71] text-[20px] font-bold">VISA</div>
        </button>

        {/* Note Input */}
        <div className="bg-white rounded-2xl p-4 mb-6 flex items-center gap-2 border border-[#E5E5EA]">
          <input
            type="text"
            placeholder="Add note..."
            value={note}
            onChange={(e) => onNoteChange(e.target.value)}
            className="flex-1 text-[17px] text-black placeholder:text-[#C7C7CC] bg-transparent outline-none"
          />
          <Calendar className="w-5 h-5 text-[#C7C7CC]" />
        </div>

        {/* Number Pad */}
        <div className="flex-1 flex flex-col justify-between pb-6">
          <div className="grid grid-cols-3 gap-y-3">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
              <button
                key={num}
                onClick={() => handleNumberClick(num.toString())}
                className="h-16 flex items-center justify-center text-[32px] font-light text-black active:bg-black/5 rounded-xl transition-colors"
              >
                {num}
              </button>
            ))}
            <button
              onClick={() => handleNumberClick('.')}
              className="h-16 flex items-center justify-center text-[32px] font-light text-black active:bg-black/5 rounded-xl transition-colors"
            >
              .
            </button>
            <button
              onClick={() => handleNumberClick('0')}
              className="h-16 flex items-center justify-center text-[32px] font-light text-black active:bg-black/5 rounded-xl transition-colors"
            >
              0
            </button>
            <button
              onClick={() => handleNumberClick('delete')}
              className="h-16 flex items-center justify-center active:bg-black/5 rounded-xl transition-colors"
            >
              <svg width="28" height="20" viewBox="0 0 28 20" fill="none">
                <path d="M22 2L6 18M6 2L22 18" stroke="black" strokeWidth="2.5" strokeLinecap="round"/>
              </svg>
            </button>
          </div>

          {/* Send Money Button */}
          <button
            onClick={onSendMoney}
            className="w-full h-14 bg-[#CDFF00] rounded-2xl text-black text-[18px] font-semibold mt-6 shadow-lg active:scale-[0.98] transition-transform"
          >
            Send Money
          </button>
        </div>
      </div>
    </div>
  );
}
