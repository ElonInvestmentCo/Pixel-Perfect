import { Check } from 'lucide-react';

interface SuccessScreenProps {
  onBackToHomepage: () => void;
}

export function SuccessScreen({ onBackToHomepage }: SuccessScreenProps) {
  return (
    <div className="min-h-screen h-full w-full bg-gradient-to-b from-[#5B5FEF] to-[#6D72FF] flex flex-col overflow-hidden">

      {/* Success Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-8 py-12">
        {/* Animated Checkmark */}
        <div className="relative mb-16">
          {/* Outer ring - large */}
          <div className="absolute inset-0 w-64 h-64 -translate-x-1/2 -translate-y-1/2 left-1/2 top-1/2">
            <div className="w-full h-full rounded-full bg-white/5 animate-pulse"></div>
          </div>
          {/* Middle ring */}
          <div className="absolute inset-0 w-48 h-48 -translate-x-1/2 -translate-y-1/2 left-1/2 top-1/2">
            <div className="w-full h-full rounded-full bg-white/10"></div>
          </div>
          {/* Inner ring */}
          <div className="absolute inset-0 w-32 h-32 -translate-x-1/2 -translate-y-1/2 left-1/2 top-1/2">
            <div className="w-full h-full rounded-full bg-[#8B8FFF]"></div>
          </div>
          {/* Center circle with checkmark */}
          <div className="relative w-24 h-24 rounded-full bg-[#CDFF00] flex items-center justify-center shadow-2xl">
            <Check className="w-12 h-12 text-black" strokeWidth={3.5} />
          </div>
        </div>

        {/* Success Text */}
        <h1 className="text-white text-[42px] font-bold mb-4 text-center">All Done!</h1>
        <p className="text-white/80 text-[18px] text-center leading-relaxed max-w-sm">
          You have successfully transferred your money.
        </p>
      </div>

      {/* Bottom Section */}
      <div className="px-6 pb-6">
        <button
          onClick={onBackToHomepage}
          className="w-full h-14 bg-[#CDFF00] rounded-2xl text-black text-[18px] font-semibold shadow-lg active:scale-[0.98] transition-transform"
        >
          Back to Homepage
        </button>
      </div>
    </div>
  );
}
