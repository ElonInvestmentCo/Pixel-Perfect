import { useState } from 'react';
import { TransferScreen } from './components/TransferScreen';
import { ChooseRecipientsModal } from './components/ChooseRecipientsModal';
import { ConfirmTransferModal } from './components/ConfirmTransferModal';
import { SuccessScreen } from './components/SuccessScreen';

interface Recipient {
  id: string;
  name: string;
  accountNumber: string;
  cardType: 'VISA' | 'MASTERCARD' | 'CHASE' | 'HSBC';
  avatar: string;
}

export const recentPayed: Recipient[] = [
  { id: '1', name: 'Rayford Chenail', accountNumber: '**** 3261', cardType: 'VISA', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop' },
  { id: '2', name: 'Krishna Barbe', accountNumber: '**** 4532', cardType: 'CHASE', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop' },
];

export const allContacts: Recipient[] = [
  { id: '3', name: 'Cyndy Lillibridge', accountNumber: '**** 0988', cardType: 'MASTERCARD', avatar: 'https://images.unsplash.com/photo-1607503873903-c5e95f80d7b9?w=400&h=400&fit=crop' },
  { id: '4', name: 'Willard Purnell', accountNumber: '**** 1652', cardType: 'HSBC', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop' },
];

export default function App() {
  const [screen, setScreen] = useState<'transfer' | 'success'>('transfer');
  const [showChooseRecipients, setShowChooseRecipients] = useState(false);
  const [showConfirmTransfer, setShowConfirmTransfer] = useState(false);
  const [amount, setAmount] = useState('1,567.00');
  const [selectedRecipient, setSelectedRecipient] = useState<Recipient>({
    id: '1',
    name: 'Rayford Chenail',
    accountNumber: '**** 3261',
    cardType: 'VISA',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop'
  });
  const [note, setNote] = useState('');

  const handleRecipientClick = () => {
    setShowChooseRecipients(true);
  };

  const handleSelectRecipient = (recipient: Recipient) => {
    setSelectedRecipient(recipient);
    setShowChooseRecipients(false);
  };

  const handleSendMoney = () => {
    setShowConfirmTransfer(true);
  };

  const handleConfirmTransfer = () => {
    setShowConfirmTransfer(false);
    setScreen('success');
  };

  const handleBackToHomepage = () => {
    setScreen('transfer');
    setAmount('1,567.00');
    setNote('');
  };

  if (screen === 'success') {
    return <SuccessScreen onBackToHomepage={handleBackToHomepage} />;
  }

  return (
    <>
      <TransferScreen
        amount={amount}
        recipient={selectedRecipient}
        note={note}
        onRecipientClick={handleRecipientClick}
        onSendMoney={handleSendMoney}
        onAmountChange={setAmount}
        onNoteChange={setNote}
      />

      {showChooseRecipients && (
        <ChooseRecipientsModal
          onClose={() => setShowChooseRecipients(false)}
          onSelectRecipient={handleSelectRecipient}
          selectedRecipient={selectedRecipient}
        />
      )}

      {showConfirmTransfer && (
        <ConfirmTransferModal
          amount={amount}
          recipient={selectedRecipient}
          note={note}
          onClose={() => setShowConfirmTransfer(false)}
          onConfirm={handleConfirmTransfer}
        />
      )}
    </>
  );
}
