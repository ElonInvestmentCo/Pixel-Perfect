
  # Replicate and Wire Screens

  This is a code bundle for Replicate and Wire Screens. The original project is available at https://www.figma.com/design/YNNw5ODMSuIPJ2AgpnPD6v/Replicate-and-Wire-Screens.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  