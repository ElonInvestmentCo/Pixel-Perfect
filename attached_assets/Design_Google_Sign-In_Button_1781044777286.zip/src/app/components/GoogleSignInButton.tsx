import { useState } from "react";
import ClipPathGroup from "../../imports/ClipPathGroup/index";
import VectorText from "../../imports/Vector-1/index";
import VectorWhiteFill from "../../imports/Vector-2/index";

export function GoogleSignInButton() {
  const [isHovered, setIsHovered] = useState(false);
  const [isPressed, setIsPressed] = useState(false);

  return (
    <button
      type="button"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => { setIsHovered(false); setIsPressed(false); }}
      onMouseDown={() => setIsPressed(true)}
      onMouseUp={() => setIsPressed(false)}
      style={{
        position: "relative",
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        width: "148px",
        height: "32px",
        background: "#ffffff",
        border: "1px solid #747775",
        padding: 0,
        cursor: "pointer",
        outline: "none",
        WebkitTapHighlightColor: "transparent",
        transition: "box-shadow 0.2s ease",
        borderRadius: "16px",
        boxShadow: isPressed
          ? "0 1px 2px 0 rgba(60,64,67,0.30), 0 1px 3px 1px rgba(60,64,67,0.15)"
          : isHovered
          ? "0 1px 3px 0 rgba(60,64,67,0.30), 0 4px 8px 3px rgba(60,64,67,0.15)"
          : "none",
      }}
      aria-label="Sign in with Google"
    >
      {/* Hover overlay */}
      {isHovered && !isPressed && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            borderRadius: "16px",
            background: "rgba(66,133,244,0.08)",
            pointerEvents: "none",
            transition: "background 0.15s ease",
          }}
        />
      )}
      {isPressed && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            borderRadius: "16px",
            background: "rgba(66,133,244,0.12)",
            pointerEvents: "none",
          }}
        />
      )}

      {/* Content row: Google logo + text */}
      <div
        style={{
          position: "relative",
          display: "flex",
          alignItems: "center",
          gap: "8px",
          paddingLeft: "10px",
          paddingRight: "12px",
          zIndex: 1,
        }}
      >
        {/* Google G logo */}
        <div style={{ position: "relative", width: "16px", height: "16px", flexShrink: 0 }}>
          <ClipPathGroup />
        </div>

        {/* "Sign in with Google" text */}
        <div style={{ position: "relative", width: "93px", height: "11px", flexShrink: 0 }}>
          <VectorText />
        </div>
      </div>
    </button>
  );
}
