import { GoogleSignInButton } from "./components/GoogleSignInButton";

export default function App() {
  return (
    <div className="size-full flex flex-col items-center justify-center gap-8 bg-white">
      {/* MARKER-MAKE-KIT-INVOKED */}
      {/* Light background demo */}
      <div className="flex flex-col items-center gap-6">
        <div className="flex items-center justify-center p-8">
          <GoogleSignInButton />
        </div>
      </div>
    </div>
  );
}
