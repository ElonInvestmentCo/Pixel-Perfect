import { X, CreditCard } from 'lucide-react';

export default function App() {
  return (
    <div className="h-screen w-full relative overflow-hidden bg-gradient-to-b from-[#4a4a8d] via-[#4f4f99] to-[#5858a8]">
      {/* iOS Status Bar */}
      <div className="flex items-center justify-between px-7 pt-3 pb-2">
        <div className="text-white font-semibold tracking-[-0.4px]" style={{ fontSize: '17px' }}>
          9:41
        </div>
        <div className="flex items-center gap-[6px]">
          {/* Signal bars */}
          <svg width="18" height="12" viewBox="0 0 18 12" fill="none">
            <rect x="0" y="7" width="2.5" height="5" rx="1" fill="white"/>
            <rect x="4" y="5" width="2.5" height="7" rx="1" fill="white"/>
            <rect x="8" y="3" width="2.5" height="9" rx="1" fill="white"/>
            <rect x="12" y="1" width="2.5" height="11" rx="1" fill="white"/>
          </svg>
          {/* WiFi */}
          <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
            <path d="M8 12C8.69036 12 9.25 11.4404 9.25 10.75C9.25 10.0596 8.69036 9.5 8 9.5C7.30964 9.5 6.75 10.0596 6.75 10.75C6.75 11.4404 7.30964 12 8 12Z" fill="white"/>
            <path d="M8 7C9.933 7 11.683 7.783 12.95 9.05L14.364 7.636C12.68 5.95 10.45 5 8 5C5.55 5 3.32 5.95 1.636 7.636L3.05 9.05C4.317 7.783 6.067 7 8 7Z" fill="white"/>
            <path d="M8 2C11.15 2 14.05 3.233 16.192 5.364L14.778 6.778C13.05 5.05 10.65 4 8 4C5.35 4 2.95 5.05 1.222 6.778L-0.192001 5.364C1.95 3.233 4.85 2 8 2Z" fill="white"/>
          </svg>
          {/* Battery */}
          <svg width="25" height="12" viewBox="0 0 25 12" fill="none">
            <rect x="0.5" y="0.5" width="21" height="11" rx="2.5" stroke="white" strokeOpacity="0.4"/>
            <rect x="2" y="2" width="18" height="8" rx="1.5" fill="white"/>
            <path d="M23 4C23 3.44772 23.4477 3 24 3C24.5523 3 25 3.44772 25 4V8C25 8.55228 24.5523 9 24 9C23.4477 9 23 8.55228 23 8V4Z" fill="white" fillOpacity="0.4"/>
          </svg>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-6 relative">
        <button className="w-11 h-11 flex items-center justify-center">
          <svg width="11" height="19" viewBox="0 0 11 19" fill="none">
            <path d="M9.5 1.5L1.5 9.5L9.5 17.5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.3"/>
          </svg>
        </button>
        <h1 className="text-white/30 font-medium tracking-[-0.3px]" style={{ fontSize: '18px' }}>
          Top Up Balance
        </h1>
        <button className="w-11 h-11 flex items-center justify-center">
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <circle cx="11" cy="11" r="10" stroke="white" strokeWidth="1.5" strokeOpacity="0.3"/>
            <circle cx="11" cy="16" r="0.5" fill="white" fillOpacity="0.3"/>
            <path d="M11 7V13" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeOpacity="0.3"/>
          </svg>
        </button>
      </div>

      {/* Background blurred section */}
      <div className="px-6 mt-8 opacity-20 blur-[2px]">
        <div className="text-white/70 mb-4 font-medium" style={{ fontSize: '20px' }}>Add Money</div>
        <div className="bg-white/15 backdrop-blur-sm rounded-[28px] p-7">
          <div className="flex items-baseline gap-2">
            <span className="text-white/80" style={{ fontSize: '36px', fontWeight: '400' }}>$</span>
            <span className="text-white/80" style={{ fontSize: '52px', fontWeight: '300', letterSpacing: '-1px' }}>1,567.00</span>
          </div>
          <div className="flex items-center gap-2 mt-6">
            <div className="bg-red-500 text-white px-3 py-1 rounded-md text-xs font-medium">USD</div>
            <span className="text-white/60" style={{ fontSize: '16px' }}>$60</span>
          </div>
        </div>
      </div>

      {/* Confirmation Modal */}
      <div className="absolute inset-x-0 bottom-0 bg-white rounded-t-[36px] shadow-2xl" style={{ paddingTop: '36px', paddingBottom: '48px' }}>
        <div className="px-7">
          {/* Header with close button */}
          <div className="flex items-center justify-between mb-7">
            <h2 className="text-black font-semibold tracking-[-0.5px]" style={{ fontSize: '28px' }}>
              Top Up Confirmation
            </h2>
            <button className="w-7 h-7 flex items-center justify-center text-gray-400">
              <X size={26} strokeWidth={2} />
            </button>
          </div>

          {/* Divider */}
          <div className="h-[1px] bg-gray-200 mb-10"></div>

          {/* Transaction Details */}
          <div className="space-y-8">
            {/* Top up ID */}
            <div className="flex items-center justify-between">
              <span className="text-gray-500" style={{ fontSize: '17px', fontWeight: '400' }}>Top up ID</span>
              <span className="text-black font-semibold tracking-[-0.3px]" style={{ fontSize: '17px' }}>7685901XXX</span>
            </div>

            {/* Top up amount */}
            <div className="flex items-center justify-between">
              <span className="text-gray-500" style={{ fontSize: '17px', fontWeight: '400' }}>Top up amount</span>
              <span className="text-black font-semibold tracking-[-0.3px]" style={{ fontSize: '17px' }}>1,567.00 SGD</span>
            </div>

            {/* Top up fee */}
            <div className="flex items-center justify-between">
              <span className="text-gray-500" style={{ fontSize: '17px', fontWeight: '400' }}>Top up fee</span>
              <span className="font-semibold tracking-[-0.3px]" style={{ fontSize: '17px', color: '#00bfa5' }}>Free</span>
            </div>

            {/* Payment method */}
            <div className="flex items-center justify-between">
              <span className="text-gray-500" style={{ fontSize: '17px', fontWeight: '400' }}>Payment method</span>
              <div className="flex items-center gap-2">
                <CreditCard size={21} className="text-black" strokeWidth={2} />
                <span className="text-black font-semibold tracking-[-0.3px]" style={{ fontSize: '17px' }}>Mastercards</span>
              </div>
            </div>

            {/* Time */}
            <div className="flex items-center justify-between">
              <span className="text-gray-500" style={{ fontSize: '17px', fontWeight: '400' }}>Time</span>
              <span className="text-black font-semibold tracking-[-0.3px]" style={{ fontSize: '17px' }}>May 10, 9:00 AM</span>
            </div>

            {/* Total amount */}
            <div className="flex items-center justify-between">
              <span className="text-gray-500" style={{ fontSize: '17px', fontWeight: '400' }}>Total amount</span>
              <span className="text-black font-semibold tracking-[-0.3px]" style={{ fontSize: '17px' }}>1,567.00 SGD</span>
            </div>
          </div>

          {/* Confirm Button */}
          <button
            className="w-full mt-12 rounded-[24px] py-[18px] font-semibold transition-transform active:scale-[0.98] tracking-[-0.3px]"
            style={{
              backgroundColor: '#c8ff00',
              fontSize: '19px',
              color: '#000000'
            }}
          >
            Confirm Top Up
          </button>
        </div>

        {/* iPhone Home Indicator */}
        <div className="flex justify-center mt-6">
          <div className="w-36 h-[5px] bg-black rounded-full"></div>
        </div>
      </div>
    </div>
  );
}