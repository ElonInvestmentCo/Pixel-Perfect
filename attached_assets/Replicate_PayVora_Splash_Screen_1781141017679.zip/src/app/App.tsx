import { motion } from "motion/react";

/* ─── Brand tokens — matched to onboarding screen ──────────────
   Background : #e8e8ea  (light warm gray)
   Accent     : #e6f51b  (lime yellow-green CTA button)
   Dark       : #0d1d3a  (deep navy — logo + text)
──────────────────────────────────────────────────────────────── */
const BG     = "#e8e8ea";
const ACCENT = "#e6f51b";
const NAVY   = "#0d1d3a";
const DARK   = "#1a1a2e";

/* ─── Screen dimensions ────────────────────────────────────────*/
const SW = 390;
const SH = 844;
const CX = SW / 2;
const CY = SH / 2;

/* ══════════════════════════════════════════════════════════════
   BG LAYER — Light warm-gray base + very subtle vignette
══════════════════════════════════════════════════════════════ */
function Background() {
  return (
    <svg width={SW} height={SH} viewBox={`0 0 ${SW} ${SH}`}
      style={{ position: "absolute", inset: 0 }} preserveAspectRatio="none">
      <defs>
        {/* Matches the flat light-gray of the onboarding */}
        <linearGradient id="bgBase" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%"   stopColor="#ececee" />
          <stop offset="50%"  stopColor={BG}      />
          <stop offset="100%" stopColor="#e2e2e4" />
        </linearGradient>
        {/* Subtle center lift (mimics the onboarding's light circle area) */}
        <radialGradient id="centerLift" cx="50%" cy="48%" r="42%">
          <stop offset="0%"   stopColor="#f4f4f6" stopOpacity="0.9" />
          <stop offset="100%" stopColor="#f4f4f6" stopOpacity="0"   />
        </radialGradient>
        {/* Soft edge vignette */}
        <radialGradient id="vignette" cx="50%" cy="50%" r="70%">
          <stop offset="60%"  stopColor="transparent"  />
          <stop offset="100%" stopColor="rgba(0,0,0,0.06)" />
        </radialGradient>
        {/* Subtle lime bloom behind logo */}
        <radialGradient id="accentBloom" cx="50%" cy="50%" r="28%">
          <stop offset="0%"   stopColor={ACCENT} stopOpacity="0.09" />
          <stop offset="100%" stopColor={ACCENT} stopOpacity="0"    />
        </radialGradient>
      </defs>
      <rect width={SW} height={SH} fill="url(#bgBase)"     />
      <rect width={SW} height={SH} fill="url(#centerLift)" />
      <rect width={SW} height={SH} fill="url(#vignette)"   />
      <rect width={SW} height={SH} fill="url(#accentBloom)" />
    </svg>
  );
}

/* ══════════════════════════════════════════════════════════════
   LAYER 1 — Soft diamond/crosshatch geometric grid  (3 %)
══════════════════════════════════════════════════════════════ */
function GeometricGrid() {
  const STEP = 44;
  const els: React.ReactElement[] = [];
  for (let i = -SH; i < SW + SH; i += STEP) {
    els.push(
      <line key={`a${i}`} x1={i} y1={0} x2={i + SH} y2={SH}
        stroke={DARK} strokeWidth="0.45" />,
      <line key={`b${i}`} x1={i} y1={SH} x2={i + SH} y2={0}
        stroke={DARK} strokeWidth="0.45" />
    );
  }
  return (
    <svg width={SW} height={SH} viewBox={`0 0 ${SW} ${SH}`}
      style={{ position: "absolute", inset: 0, opacity: 0.03 }}>
      {els}
    </svg>
  );
}

/* ══════════════════════════════════════════════════════════════
   LAYER 2 — Globe silhouette: outer ring + lat/lon grid  (4 %)
   Mirrors the large faint circle visible in the onboarding bg
══════════════════════════════════════════════════════════════ */
function GlobeLayer() {
  const R  = 162;
  const GX = CX;
  const GY = CY + 8;

  const latEls: React.ReactElement[] = [];
  [-60, -30, 0, 30, 60].forEach((deg, i) => {
    const rad  = (deg * Math.PI) / 180;
    const ry   = R * Math.cos(rad);
    const yOff = R * Math.sin(rad);
    latEls.push(
      <ellipse key={i} cx={GX} cy={GY + yOff}
        rx={ry} ry={Math.max(ry * 0.22, 2)}
        fill="none" stroke={DARK} strokeWidth="0.55" />
    );
  });

  const lonEls: React.ReactElement[] = [];
  [0, 30, 60, 90, 120, 150].forEach((deg, i) => {
    const rad = (deg * Math.PI) / 180;
    lonEls.push(
      <ellipse key={i} cx={GX} cy={GY}
        rx={R * Math.max(Math.abs(Math.sin(rad)), 0.05)}
        ry={R}
        fill="none" stroke={DARK} strokeWidth="0.55" />
    );
  });

  return (
    <svg width={SW} height={SH} viewBox={`0 0 ${SW} ${SH}`}
      style={{ position: "absolute", inset: 0 }}>
      {/* Outer globe ring — 5 % */}
      <circle cx={GX} cy={GY} r={R}
        fill="none" stroke={DARK} strokeWidth="0.9" opacity="0.05" />
      {/* Inner ring (depth) — 3 % */}
      <circle cx={GX} cy={GY} r={R * 0.65}
        fill="none" stroke={DARK} strokeWidth="0.45" opacity="0.03" />
      {/* Lime equator accent — 6 % */}
      <ellipse cx={GX} cy={GY} rx={R} ry={R * 0.22}
        fill="none" stroke={ACCENT} strokeWidth="0.6" opacity="0.06" />
      {/* Lat lines — 4 % */}
      <g opacity="0.04">{latEls}</g>
      {/* Lon lines — 4 % */}
      <g opacity="0.04">{lonEls}</g>
    </svg>
  );
}

/* ══════════════════════════════════════════════════════════════
   LAYER 3 — World-map dot pattern  (6 %)
   56 × 24 equirectangular grid, '#' = land
══════════════════════════════════════════════════════════════ */
const MAP_ROWS = [
  "                                                        ",
  "       ####     ##                                      ",
  "     ########  ####  ##   ###                           ",
  "    ######### ###### ### #####  ##########              ",
  "    ######### ########## ####################################",
  "    ######### ########## ###################################",
  "     ######## ########## ##################################",
  "     ######## ########## #################################",
  "      ####### #########  ############################  ## ",
  "       ###### #########  ###########################   ## ",
  "       ######  ########  ######### ###########  ##########",
  "       ######  ########  ######### ###########  ##########",
  "  #    ######  ########  ######### #####         #########",
  " ###   ######  ########  ########  #####          ########",
  " ####  #####    #######  ########  ####            ###### ",
  " ####  ####      ######  #######    ###            ###### ",
  "  ###  ###       ######  ######                    #####  ",
  "  ###  ##         #####  #####                     ####   ",
  "   ##   #          ####   ####                      ##    ",
  "   ##               ###    ##                             ",
  "    #                ##                                   ",
  "                      #                                   ",
  "                                                          ",
  "                                                          ",
];
const MCOLS = 56;
const MCW   = SW / MCOLS;
const MCH   = (SH * 0.86) / 24;
const MOFFY = SH * 0.06;

function WorldMapDots() {
  const dots: { cx: number; cy: number }[] = [];
  MAP_ROWS.forEach((row, r) => {
    for (let c = 0; c < MCOLS; c++) {
      if (row[c] === "#")
        dots.push({ cx: c * MCW + MCW / 2, cy: MOFFY + r * MCH + MCH / 2 });
    }
  });
  return (
    <svg width={SW} height={SH} viewBox={`0 0 ${SW} ${SH}`}
      style={{ position: "absolute", inset: 0, opacity: 0.07 }}>
      {dots.map((d, i) => (
        <circle key={i} cx={d.cx} cy={d.cy} r={2.0} fill={DARK} />
      ))}
    </svg>
  );
}

/* ══════════════════════════════════════════════════════════════
   LAYER 4 — Financial network: routes, nodes, currency labels
══════════════════════════════════════════════════════════════ */
function proj(lat: number, lng: number): [number, number] {
  return [
    ((lng + 180) / 360) * SW,
    ((90 - lat) / 180) * (SH * 0.82) + SH * 0.07,
  ];
}

const HUBS: Record<string, { p: [number, number]; sym: string }> = {
  ny:    { p: proj(40.7,  -74.0), sym: "$"   },
  lon:   { p: proj(51.5,   -0.1), sym: "£"   },
  fra:   { p: proj(50.1,    8.7), sym: "€"   },
  dxb:   { p: proj(25.2,   55.3), sym: "AED" },
  sgp:   { p: proj( 1.3,  103.8), sym: "S$"  },
  tyo:   { p: proj(35.7,  139.7), sym: "¥"   },
  lag:   { p: proj( 6.5,    3.4), sym: "₦"   },
  syd:   { p: proj(-33.9, 151.2), sym: "A$"  },
  mum:   { p: proj(19.1,   72.9), sym: "₹"   },
};

const ROUTES: [string, string][] = [
  ["ny",  "lon"], ["lon", "fra"], ["lon", "dxb"], ["lon", "lag"],
  ["dxb", "sgp"], ["dxb", "mum"], ["sgp", "tyo"],
  ["ny",  "lag"], ["mum", "sgp"], ["tyo", "syd"],
];

function arc(a: [number,number], b: [number,number]) {
  const mx = (a[0]+b[0])/2;
  const my = (a[1]+b[1])/2 - 52;
  return `M${a[0]},${a[1]} Q${mx},${my} ${b[0]},${b[1]}`;
}

function NetworkLayer() {
  return (
    <svg width={SW} height={SH} viewBox={`0 0 ${SW} ${SH}`}
      style={{ position: "absolute", inset: 0 }}>

      {/* Secondary route arcs — dark  4 % */}
      <g fill="none" stroke={DARK} strokeWidth="0.6" opacity="0.04">
        {ROUTES.map(([a,b],i) => <path key={i} d={arc(HUBS[a].p, HUBS[b].p)} />)}
      </g>

      {/* Primary accent arcs — lime  5 % */}
      <g fill="none" stroke={ACCENT} strokeWidth="0.75"
        strokeDasharray="4 10" opacity="0.05">
        {["ny-lon","lon-dxb","dxb-sgp","sgp-tyo"].map((k,i) => {
          const [a,b] = k.split("-");
          return <path key={i} d={arc(HUBS[a].p, HUBS[b].p)} />;
        })}
      </g>

      {/* Hub rings — 6 % */}
      {Object.values(HUBS).map(({p}, i) => (
        <g key={i}>
          <circle cx={p[0]} cy={p[1]} r={5.5}
            fill="none" stroke={DARK} strokeWidth="0.6" opacity="0.06" />
          <circle cx={p[0]} cy={p[1]} r={2}
            fill={DARK} opacity="0.07" />
        </g>
      ))}

      {/* Lime accent node on key hubs — 7 % */}
      {["lon","dxb","sgp","ny"].map(k => (
        <circle key={k} cx={HUBS[k].p[0]} cy={HUBS[k].p[1]} r={2.2}
          fill={ACCENT} opacity="0.07" />
      ))}

      {/* Currency labels — 5 % */}
      {Object.values(HUBS).map(({p, sym}, i) => (
        <text key={i} x={p[0]+7} y={p[1]-6}
          fontSize={sym.length > 1 ? 6.5 : 8.5}
          fontFamily="-apple-system, system-ui, sans-serif"
          fontWeight="500" fill={DARK} opacity="0.05">
          {sym}
        </text>
      ))}
    </svg>
  );
}

/* ══════════════════════════════════════════════════════════════
   LAYER 5 — Scattered ambient currency symbols  (3–4 %)
══════════════════════════════════════════════════════════════ */
const SCATTER = [
  { s:"$",   x:32,  y:145, fs:23, op:0.04 },
  { s:"€",   x:228, y:92,  fs:19, op:0.035},
  { s:"£",   x:155, y:308, fs:17, op:0.03 },
  { s:"¥",   x:345, y:182, fs:21, op:0.04 },
  { s:"₦",   x:168, y:608, fs:18, op:0.035},
  { s:"AED", x:274, y:462, fs:9,  op:0.03 },
  { s:"₹",   x:295, y:335, fs:16, op:0.035},
  { s:"€",   x:60,  y:525, fs:14, op:0.025},
  { s:"$",   x:340, y:530, fs:13, op:0.025},
  { s:"¥",   x:312, y:650, fs:12, op:0.025},
];

function ScatterCurrency() {
  return (
    <svg width={SW} height={SH} viewBox={`0 0 ${SW} ${SH}`}
      style={{ position: "absolute", inset: 0 }}>
      {SCATTER.map((s,i) => (
        <text key={i} x={s.x} y={s.y} fontSize={s.fs}
          fontFamily="-apple-system, system-ui, sans-serif"
          fontWeight="300" fill={DARK} opacity={s.op}>{s.s}</text>
      ))}
    </svg>
  );
}

/* ══════════════════════════════════════════════════════════════
   LAYER 6 — Corner accent arcs  (3–5 %)
══════════════════════════════════════════════════════════════ */
function CornerAccents() {
  return (
    <svg width={SW} height={SH} viewBox={`0 0 ${SW} ${SH}`}
      style={{ position: "absolute", inset: 0 }}>
      {/* Top-left sweeping arcs — dark 4 % */}
      <path d="M0,190 Q0,0 190,0"
        fill="none" stroke={DARK} strokeWidth="0.6" opacity="0.04" />
      <path d="M0,250 Q0,0 250,0"
        fill="none" stroke={DARK} strokeWidth="0.4" opacity="0.03" />
      {/* Bottom-right sweeping arcs — dark 4 % */}
      <path d={`M${SW},${SH-190} Q${SW},${SH} ${SW-190},${SH}`}
        fill="none" stroke={DARK} strokeWidth="0.6" opacity="0.04" />
      <path d={`M${SW},${SH-250} Q${SW},${SH} ${SW-250},${SH}`}
        fill="none" stroke={DARK} strokeWidth="0.4" opacity="0.03" />
      {/* Lime accent corners — 6 % */}
      <path d={`M${SW-80},0 Q${SW},0 ${SW},80`}
        fill="none" stroke={ACCENT} strokeWidth="0.8" opacity="0.06" />
      <path d={`M0,${SH-80} Q0,${SH} 80,${SH}`}
        fill="none" stroke={ACCENT} strokeWidth="0.8" opacity="0.06" />
    </svg>
  );
}

/* ══════════════════════════════════════════════════════════════
   LOGO — Dual-color double circle
   Left circle : deep navy  (#0d1d3a)   — visible on light bg
   Right circle: lime accent (#e6f51b) — brand identity
   Intersection: navy clips over lime   — creates two-ring read
══════════════════════════════════════════════════════════════ */
function PayVoraLogo({ size = 96 }: { size?: number }) {
  const r   = size * 0.305;
  const gap = size * 0.09;
  const cx1 = size / 2 - gap;
  const cx2 = size / 2 + gap;
  const cy  = size / 2;

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <defs>
        {/* Clip to left circle — darkens the intersection from the right */}
        <clipPath id="lc2"><circle cx={cx1} cy={cy} r={r} /></clipPath>
      </defs>
      {/* Right circle: lime */}
      <circle cx={cx2} cy={cy} r={r} fill={ACCENT} />
      {/* Left circle: navy — sits on top */}
      <circle cx={cx1} cy={cy} r={r} fill={NAVY} />
      {/* Intersection: right circle clips left, showing a partial lime */}
      <circle cx={cx2} cy={cy} r={r}
        fill={ACCENT} clipPath="url(#lc2)" opacity="0.45" />
    </svg>
  );
}

/* ══════════════════════════════════════════════════════════════
   STATUS BAR
══════════════════════════════════════════════════════════════ */
function SignalBars({ color }: { color: string }) {
  return (
    <svg width="17" height="12" viewBox="0 0 17 12" fill={color}>
      <rect x="0"    y="7"   width="3" height="5"   rx="0.8" />
      <rect x="4.5"  y="4.5" width="3" height="7.5" rx="0.8" />
      <rect x="9"    y="2"   width="3" height="10"  rx="0.8" />
      <rect x="13.5" y="0"   width="3" height="12"  rx="0.8" opacity="0.4" />
    </svg>
  );
}
function WifiIcon({ color }: { color: string }) {
  return (
    <svg width="16" height="12" viewBox="0 0 16 12"
      fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round">
      <path d="M8 9.5 L8 9.5" strokeWidth="2.2" />
      <path d="M5.2 7.2 Q8 4.8 10.8 7.2" />
      <path d="M2.4 4.8 Q8 0.8 13.6 4.8" />
    </svg>
  );
}
function BatteryIcon({ color }: { color: string }) {
  return (
    <svg width="25" height="12" viewBox="0 0 25 12">
      <rect x="0" y="1" width="21" height="10" rx="2.5"
        fill="none" stroke={color} strokeWidth="1.2" opacity="0.7" />
      <rect x="1.5" y="2.5" width="16" height="7" rx="1.5" fill={color} />
      <path d="M22 4.5 Q24 4.5 24 6 Q24 7.5 22 7.5" fill={color} opacity="0.5" />
    </svg>
  );
}

/* ══════════════════════════════════════════════════════════════
   iPHONE 15 FRAME
══════════════════════════════════════════════════════════════ */
function IPhoneFrame({ children }: { children: React.ReactNode }) {
  return (
    <div style={{
      position: "relative",
      width:  SW + 22,
      height: SH + 26,
      borderRadius: 54,
      background: "linear-gradient(145deg,#3c3c3e 0%,#1c1c1e 45%,#101012 75%,#2c2c2e 100%)",
      boxShadow: [
        "0 0 0 1px rgba(255,255,255,0.13)",
        "0 50px 120px rgba(0,0,0,0.7)",
        "0 12px 36px rgba(0,0,0,0.45)",
        "inset 0 1px 0 rgba(255,255,255,0.09)",
      ].join(", "),
      flexShrink: 0,
    }}>
      {/* Volume buttons */}
      {[{ top:82, h:32 }, { top:140, h:56 }, { top:208, h:56 }].map((b,i) => (
        <div key={i} style={{
          position:"absolute", left:-5, top:b.top, width:4, height:b.h,
          borderRadius:"2px 0 0 2px",
          background:"linear-gradient(90deg,#2a2a2c,#3c3c3e)",
          boxShadow:"inset 0 1px 0 rgba(255,255,255,0.1),-1px 0 3px rgba(0,0,0,0.5)",
        }} />
      ))}
      {/* Power button */}
      <div style={{
        position:"absolute", right:-5, top:168, width:4, height:78,
        borderRadius:"0 2px 2px 0",
        background:"linear-gradient(90deg,#3c3c3e,#2a2a2c)",
        boxShadow:"inset 0 1px 0 rgba(255,255,255,0.1),1px 0 3px rgba(0,0,0,0.5)",
      }} />
      {/* Screen */}
      <div style={{
        position:"absolute", top:13, left:11,
        width:SW, height:SH,
        borderRadius:44, overflow:"hidden",
        background:BG,
      }}>
        {children}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   APP ROOT
══════════════════════════════════════════════════════════════ */
export default function App() {
  return (
    <div style={{
      width:"100%", height:"100%",
      display:"flex", alignItems:"center", justifyContent:"center",
      background:"#d4d4d6",          /* neutral desktop bg */
      padding:"20px 0", boxSizing:"border-box", overflow:"auto",
    }}>
      <IPhoneFrame>
        <div style={{ position:"relative", width:SW, height:SH, overflow:"hidden" }}>

          {/* ── Layers (bottom → top) ── */}
          <Background />
          <GeometricGrid />
          <GlobeLayer />
          <WorldMapDots />
          <NetworkLayer />
          <ScatterCurrency />
          <CornerAccents />

          {/* ── Status bar ── */}
          <div style={{
            position:"absolute", top:0, left:0, right:0, height:54, zIndex:30,
            display:"flex", alignItems:"flex-end", justifyContent:"space-between",
            padding:"0 28px 6px",
          }}>
            <span style={{
              color: NAVY, fontSize:15, fontWeight:600,
              fontFamily:"-apple-system,'SF Pro Display',system-ui,sans-serif",
              letterSpacing:"0.02em",
            }}>9:41</span>
            <div style={{ display:"flex", alignItems:"center", gap:6 }}>
              <SignalBars color={NAVY} />
              <WifiIcon   color={NAVY} />
              <BatteryIcon color={NAVY} />
            </div>
          </div>

          {/* ── Dynamic Island ── */}
          <div style={{
            position:"absolute", top:13, left:"50%",
            transform:"translateX(-50%)",
            width:120, height:34, borderRadius:20,
            background:"#000", zIndex:40,
          }} />

          {/* ── Subtle lime glow halo behind logo ── */}
          <div style={{
            position:"absolute",
            top:"50%", left:"50%",
            transform:"translate(-50%,-55%)",
            width:220, height:220, borderRadius:"50%",
            background:`radial-gradient(circle, ${ACCENT}22 0%, ${ACCENT}0a 45%, transparent 70%)`,
            zIndex:10,
          }} />

          {/* ── Logo + brand name ── */}
          <div style={{
            position:"absolute", inset:0, zIndex:20,
            display:"flex", flexDirection:"column",
            alignItems:"center", justifyContent:"center",
            gap:18,
          }}>
            <motion.div
              initial={{ opacity:0, scale:0.65 }}
              animate={{ opacity:1, scale:1 }}
              transition={{ duration:0.9, ease:[0.34,1.46,0.64,1] }}
              style={{
                filter:`drop-shadow(0 4px 24px ${ACCENT}55) drop-shadow(0 1px 6px rgba(0,0,0,0.12))`,
              }}
            >
              <PayVoraLogo size={100} />
            </motion.div>

            {/* Brand name — dark navy, matching onboarding typography */}
            <motion.div
              initial={{ opacity:0, y:16 }}
              animate={{ opacity:1, y:0 }}
              transition={{ duration:0.6, delay:0.45, ease:"easeOut" }}
              style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:4 }}
            >
              <p style={{
                margin:0, color:NAVY,
                fontSize:26, fontWeight:700,
                letterSpacing:"0.025em",
                fontFamily:"-apple-system,'SF Pro Display',system-ui,sans-serif",
              }}>
                PayVora
              </p>
              <motion.p
                initial={{ opacity:0 }}
                animate={{ opacity:1 }}
                transition={{ duration:0.5, delay:0.75 }}
                style={{
                  margin:0,
                  color:"rgba(13,29,58,0.38)",
                  fontSize:10, fontWeight:400,
                  letterSpacing:"0.2em",
                  textTransform:"uppercase",
                  fontFamily:"-apple-system,system-ui,sans-serif",
                }}
              >
                Global Payments
              </motion.p>
            </motion.div>
          </div>

          {/* ── Home indicator — dark on light bg ── */}
          <div style={{
            position:"absolute", bottom:10, left:"50%",
            transform:"translateX(-50%)",
            width:130, height:4, borderRadius:2,
            background:"rgba(13,29,58,0.22)", zIndex:30,
          }} />
        </div>
      </IPhoneFrame>
    </div>
  );
}
