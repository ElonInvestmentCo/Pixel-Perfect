
  # Replicate PayVora Splash Screen

  This is a code bundle for Replicate PayVora Splash Screen. The original project is available at https://www.figma.com/design/7ffa1w0FZahXT8w9rCAhGd/Replicate-PayVora-Splash-Screen.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  