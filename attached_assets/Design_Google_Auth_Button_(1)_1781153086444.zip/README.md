
  # Design Google Auth Button

  This is a code bundle for Design Google Auth Button. The original project is available at https://www.figma.com/design/BqiHZlP1eFefBJOblov2l9/Design-Google-Auth-Button.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  