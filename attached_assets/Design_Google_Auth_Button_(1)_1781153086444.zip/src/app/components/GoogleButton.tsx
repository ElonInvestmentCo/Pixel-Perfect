import ClipPathGroup from "../../imports/ClipPathGroup/index";

export function GoogleButton({ onClick }: { onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      style={{
        backgroundColor: "#FFFFFF",
        border: "1px solid #E5E7EB",
        borderRadius: "18px",
        height: "64px",
        width: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: "12px",
        cursor: "pointer",
        boxShadow: "none",
        outline: "none",
      }}
    >
      <div style={{ position: "relative", width: "24px", height: "24px", flexShrink: 0 }}>
        <ClipPathGroup />
      </div>
      <span
        style={{
          fontFamily: "Inter, sans-serif",
          fontWeight: 600,
          fontSize: "17px",
          color: "#111111",
          letterSpacing: "-0.01em",
        }}
      >
        Google
      </span>
    </button>
  );
}
