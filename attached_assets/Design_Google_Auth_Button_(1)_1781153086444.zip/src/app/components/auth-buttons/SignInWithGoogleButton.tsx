import { AuthButtonBase } from "./AuthButtonBase";
import { GoogleIcon } from "./GoogleIcon";

interface SignInWithGoogleButtonProps {
  onClick?: () => void;
}

export function SignInWithGoogleButton({ onClick }: SignInWithGoogleButtonProps) {
  return (
    <AuthButtonBase
      label="Google"
      icon={<GoogleIcon />}
      onClick={onClick}
    />
  );
}
