import React from "react";

interface AuthButtonBaseProps {
  label: string;
  icon: React.ReactNode;
  onClick?: () => void;
  type?: "button" | "submit";
}

export function AuthButtonBase({ label, icon, onClick, type = "button" }: AuthButtonBaseProps) {
  return (
    <button
      type={type}
      onClick={onClick}
      style={{
        backgroundColor: "#FFFFFF",
        border: "1px solid #E5E7EB",
        borderRadius: "18px",
        height: "64px",
        width: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: "10px",
        cursor: "pointer",
        boxShadow: "none",
        outline: "none",
        padding: "0 28px",
        transition: "background-color 0.15s ease",
        WebkitAppearance: "none",
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLButtonElement).style.backgroundColor = "#F9FAFB";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLButtonElement).style.backgroundColor = "#FFFFFF";
      }}
    >
      <span
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
          width: "26px",
          height: "26px",
        }}
      >
        {icon}
      </span>
      <span
        style={{
          fontFamily: "'Inter', -apple-system, sans-serif",
          fontWeight: 600,
          fontSize: "17px",
          color: "#111111",
          letterSpacing: "-0.01em",
          lineHeight: 1,
          whiteSpace: "nowrap",
        }}
      >
        {label}
      </span>
    </button>
  );
}
