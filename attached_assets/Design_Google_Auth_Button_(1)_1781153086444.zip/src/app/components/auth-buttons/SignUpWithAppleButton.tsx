import { AuthButtonBase } from "./AuthButtonBase";
import { AppleIcon } from "./AppleIcon";

interface SignUpWithAppleButtonProps {
  onClick?: () => void;
}

export function SignUpWithAppleButton({ onClick }: SignUpWithAppleButtonProps) {
  return (
    <AuthButtonBase
      label="Apple"
      icon={<AppleIcon />}
      onClick={onClick}
    />
  );
}
