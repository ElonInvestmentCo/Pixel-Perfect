import { AuthButtonBase } from "./AuthButtonBase";
import { AppleIcon } from "./AppleIcon";

interface SignInWithAppleButtonProps {
  onClick?: () => void;
}

export function SignInWithAppleButton({ onClick }: SignInWithAppleButtonProps) {
  return (
    <AuthButtonBase
      label="Apple"
      icon={<AppleIcon />}
      onClick={onClick}
    />
  );
}
