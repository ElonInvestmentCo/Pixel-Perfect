import { AuthButtonBase } from "./AuthButtonBase";
import { GoogleIcon } from "./GoogleIcon";

interface SignUpWithGoogleButtonProps {
  onClick?: () => void;
}

export function SignUpWithGoogleButton({ onClick }: SignUpWithGoogleButtonProps) {
  return (
    <AuthButtonBase
      label="Google"
      icon={<GoogleIcon />}
      onClick={onClick}
    />
  );
}
