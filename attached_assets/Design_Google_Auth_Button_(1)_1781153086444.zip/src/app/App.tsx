import { SignInWithAppleButton } from "./components/auth-buttons/SignInWithAppleButton";
import { SignInWithGoogleButton } from "./components/auth-buttons/SignInWithGoogleButton";

export default function App() {
  return (
    <div
      style={{
        minHeight: "100vh",
        backgroundColor: "#F5F5F7",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: "24px",
      }}
    >
      {/* Divider row */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "12px",
          width: "100%",
          maxWidth: "600px",
          marginBottom: "24px",
        }}
      >
        <div style={{ flex: 1, height: "1px", backgroundColor: "#E5E7EB" }} />
        <span
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: "15px",
            color: "#9CA3AF",
            whiteSpace: "nowrap",
          }}
        >
          Or sign up with
        </span>
        <div style={{ flex: 1, height: "1px", backgroundColor: "#E5E7EB" }} />
      </div>

      {/* Buttons row */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "16px",
          width: "100%",
          maxWidth: "600px",
        }}
      >
        <SignInWithAppleButton onClick={() => console.log("Apple")} />
        <SignInWithGoogleButton onClick={() => console.log("Google")} />
      </div>
    </div>
  );
}
