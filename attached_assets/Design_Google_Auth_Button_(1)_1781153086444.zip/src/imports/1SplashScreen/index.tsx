import img1SplashScreen from "./29d51a701297657f46a8cec7f19e2ed48b6e3f49.png";

export default function Component1SplashScreen() {
  return (
    <div className="relative size-full" data-name="1. Splash Screen">
      <div className="absolute h-[812px] left-0 top-0 w-[375px]" data-name="1. Splash Screen">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={img1SplashScreen} />
      </div>
    </div>
  );
}